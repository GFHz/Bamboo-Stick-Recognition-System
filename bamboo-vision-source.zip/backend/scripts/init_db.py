"""数据库初始化脚本。

用途：清空并重建所有表 + 创建一个默认管理员账号。
开发期使用，生产环境请走 alembic 迁移。

用法：
    cd backend
    d:\\code\\program\\venv\\Scripts\\python.exe -m scripts.init_db
"""
from __future__ import annotations

import asyncio

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import hash_password
from app.database import AsyncSessionLocal, engine
from app.models import Base, User


async def _drop_and_create() -> None:
    """DROP 所有表后重建。"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        print("[init] 已清空所有表")
        await conn.run_sync(Base.metadata.create_all)
        print("[init] 已重建所有表")


async def _create_default_admin(db: AsyncSession) -> User:
    """创建一个默认管理员账号。"""
    admin = User(
        username="admin",
        password_hash=hash_password("admin123"),
        name="默认管理员",
        role=1,
        admin_id=None,
        is_active=1,
        must_change_password=0,
    )
    db.add(admin)
    await db.commit()
    await db.refresh(admin)
    print(f"[init] 已创建默认管理员：账号 admin / 密码 admin123")
    return admin


async def main() -> None:
    await _drop_and_create()
    async with AsyncSessionLocal() as db:
        await _create_default_admin(db)
    print("[init] 初始化完成")


if __name__ == "__main__":
    asyncio.run(main())
