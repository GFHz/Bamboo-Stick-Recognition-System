"""add deleted_at to users for soft-delete

Revision ID: a1b2c3d4e5f6
Revises: 973de342ada9
Create Date: 2026-06-30 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, None] = '973de342ada9'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'users',
        sa.Column('deleted_at', sa.DateTime(), nullable=True, default=None,
                  comment='软删除时间，NULL=未删除'),
    )


def downgrade() -> None:
    op.drop_column('users', 'deleted_at')
