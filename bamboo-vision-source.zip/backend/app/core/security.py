"""密码哈希工具：直接使用 bcrypt 库。

注意：项目早期用 passlib 包装 bcrypt，但 passlib 与 bcrypt >= 4.0 不兼容
（passlib 访问已移除的 bcrypt.__about__.__version__ 会崩溃）。
此处直接使用 bcrypt 库，哈希结果与旧 passlib 生成的 $2b$ 格式完全兼容。
"""
from __future__ import annotations

import bcrypt


def hash_password(plain: str) -> str:
    """对明文密码做 bcrypt 哈希。"""
    # bcrypt 限制密码不超过 72 字节，超长截断
    pwd_bytes = plain.encode("utf-8")[:72]
    return bcrypt.hashpw(pwd_bytes, bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """校验明文密码是否匹配哈希。"""
    try:
        pwd_bytes = plain.encode("utf-8")[:72]
        hash_bytes = hashed.encode("utf-8")
        return bcrypt.checkpw(pwd_bytes, hash_bytes)
    except (ValueError, TypeError):
        return False


# ============ 密码强度校验 ============
# 规则：
#   - 长度 8-16 位
#   - 必须包含字母和数字（最低门槛）
#   - 等级三档：
#       weak   弱：不满足最低门槛（如纯数字、纯字母）
#       medium 中：字母 + 数字 组合
#       strong 强：含 3 类以上字符（大写 / 小写 / 数字 / 符号）
import re

_PWD_LENGTH_PATTERN = re.compile(r"^.{8,16}$")
_UPPER = re.compile(r"[A-Z]")
_LOWER = re.compile(r"[a-z]")
_DIGIT = re.compile(r"\d")
_SYMBOL = re.compile(r"[^A-Za-z\d]")


def _char_categories(plain: str) -> int:
    """统计密码包含的字符类别数（大写/小写/数字/符号）。"""
    n = 0
    if _UPPER.search(plain):
        n += 1
    if _LOWER.search(plain):
        n += 1
    if _DIGIT.search(plain):
        n += 1
    if _SYMBOL.search(plain):
        n += 1
    return n


def password_strength(plain: str) -> str:
    """返回密码强度等级：weak / medium / strong。

    - weak:   不满足最低门槛（长度不符 或 纯数字 或 纯字母）
    - medium: 满足字母+数字组合
    - strong: 含 3 类以上字符（大写/小写/数字/符号）
    """
    if not _PWD_LENGTH_PATTERN.match(plain):
        return "weak"

    has_letter = bool(_UPPER.search(plain) or _LOWER.search(plain))
    has_digit = bool(_DIGIT.search(plain))

    # 不满足字母+数字组合 → 弱
    if not (has_letter and has_digit):
        return "weak"

    # 3 类以上 → 强
    if _char_categories(plain) >= 3:
        return "strong"

    # 字母+数字 组合 → 中
    return "medium"


def is_strong_password(plain: str) -> bool:
    """检查是否满足最低密码要求：8-16 位，至少含字母和数字。

    通过此校验仅代表可注册，不代表强度高。
    """
    if not _PWD_LENGTH_PATTERN.match(plain):
        return False
    has_letter = bool(_UPPER.search(plain) or _LOWER.search(plain))
    has_digit = bool(_DIGIT.search(plain))
    return has_letter and has_digit
