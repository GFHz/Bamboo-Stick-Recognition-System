"""价格配置模型：每个管理员/店维护自己的竹签单价历史。"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import BigInteger, Date, DateTime, ForeignKey, Numeric, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class PriceConfig(Base):
    __tablename__ = "price_config"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    admin_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False, index=True, comment="所属管理员/店")
    skewer_type: Mapped[str] = mapped_column(String(16), nullable=False, index=True, comment="固定为 bamboo")
    unit_price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False, comment="单价（元）")
    effective_date: Mapped[date] = mapped_column(Date, nullable=False, index=True, comment="设置日期（仅记录，立即生效）")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)

    def __repr__(self) -> str:
        return f"<PriceConfig admin={self.admin_id} {self.skewer_type}={self.unit_price}>"
