"""订单模型。"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, Integer, Numeric, SmallInteger, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    order_no: Mapped[str] = mapped_column(String(32), unique=True, nullable=False, index=True, comment="订单号 ORD+yyyyMMdd+6位流水")
    staff_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False, index=True, comment="员工 user_id")
    admin_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False, index=True, comment="所属管理员/店 user_id")
    bamboo_count: Mapped[int] = mapped_column(Integer, nullable=False, comment="竹签数量")
    unit_price: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False, comment="生成时锁定的竹签单价快照")
    total_amount: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False, comment="金额 = bamboo*unit_price")
    image_path: Mapped[Optional[str]] = mapped_column(String(255), nullable=True, comment="压缩图相对路径，撤销后置空")
    remark: Mapped[Optional[str]] = mapped_column(String(200), nullable=True, comment="备注")
    status: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=1, comment="1=有效, 0=已撤销")
    cancelled_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, comment="撤销时间")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    __table_args__ = (
        Index("idx_staff_created", "staff_id", "created_at"),
        Index("idx_admin_created", "admin_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<Order {self.order_no} count={self.bamboo_count} amount={self.total_amount}>"
