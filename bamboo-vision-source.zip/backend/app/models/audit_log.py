"""操作日志模型。"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, DateTime, ForeignKey, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    user_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True, comment="操作人")
    order_no: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True, comment="关联订单号")
    action: Mapped[str] = mapped_column(String(32), nullable=False, index=True, comment="cancel_order/delete_employee/update_price 等")
    detail: Mapped[Optional[str]] = mapped_column(Text, nullable=True, comment="详情 JSON")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False, index=True)

    def __repr__(self) -> str:
        return f"<AuditLog {self.action} by user={self.user_id}>"
