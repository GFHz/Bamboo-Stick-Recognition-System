"""用户模型：管理员 + 员工统一存此表。

多店设计：每个管理员代表一家店，员工通过 admin_id 绑定到所属管理员/店。
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, DateTime, ForeignKey, SmallInteger, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(32), unique=True, nullable=False, index=True, comment="账号/工号")
    password_hash: Mapped[str] = mapped_column(String(128), nullable=False, comment="bcrypt 哈希")
    name: Mapped[str] = mapped_column(String(32), nullable=False, comment="真实姓名")
    role: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=1, comment="1=管理员, 2=员工")
    admin_id: Mapped[Optional[int]] = mapped_column(
        BigInteger, ForeignKey("users.id"), nullable=True, index=True,
        comment="员工所属管理员/店；管理员自身为 NULL",
    )
    is_active: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=1, comment="1=启用, 0=停用")
    must_change_password: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=0, comment="1=下次登录强制改密")
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, default=None, comment="软删除时间，NULL=未删除")

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username} role={self.role}>"
