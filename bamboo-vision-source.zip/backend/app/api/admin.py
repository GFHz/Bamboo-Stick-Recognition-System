"""管理员业务路由：员工管理 + 统计 + 导出。每个管理员只能管理本店数据。"""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.deps.auth import require_admin
from app.models import User
from app.schemas.staff import StaffCreate, StaffListResponse, StaffOut, StaffStatusUpdate
from app.schemas.stat import DashboardSummary, StatRange
from app.services import staff_service, stat_service

router = APIRouter(prefix="/admin", tags=["管理员"])


# ===== 员工管理 =====
@router.post("/staffs", response_model=StaffOut, status_code=status.HTTP_201_CREATED)
async def create_staff(
    req: StaffCreate,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """新增员工。"""
    try:
        return await staff_service.create_staff(req, admin, db)
    except staff_service.StaffError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("/staffs", response_model=StaffListResponse)
async def list_staffs(
    page: int = 1,
    page_size: int = 20,
    keyword: Optional[str] = None,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """本店员工列表。"""
    return await staff_service.list_staffs(admin, page, page_size, keyword, db)


@router.delete("/staffs/{staff_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_staff(
    staff_id: int,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """删除员工（软删除）。"""
    try:
        await staff_service.delete_staff(staff_id, admin, db)
    except staff_service.StaffError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.patch("/staffs/{staff_id}/status", response_model=StaffOut)
async def toggle_staff_status(
    staff_id: int,
    req: StaffStatusUpdate,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """启用/停用员工账号。"""
    try:
        return await staff_service.toggle_staff_status(staff_id, req.is_active, admin, db)
    except staff_service.StaffError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


# ===== 统计 =====
@router.get("/dashboard", response_model=DashboardSummary)
async def dashboard(
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """首页汇总：本店日/月/年营收+订单数+30 天趋势。"""
    return await stat_service.get_dashboard(admin, db)


@router.get("/stats", response_model=StatRange)
async def stats(
    start_date: date = Query(...),
    end_date: date = Query(...),
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """按日期范围统计（本店）。"""
    return await stat_service.get_stat_range(admin, start_date, end_date, db)


@router.get("/export")
async def export_orders(
    start_date: date = Query(...),
    end_date: date = Query(...),
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """导出本店订单 Excel。"""
    from io import BytesIO

    content = await stat_service.export_orders(admin, start_date, end_date, db)
    filename = f"orders_{start_date}_{end_date}.xlsx"
    return StreamingResponse(
        BytesIO(content),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
