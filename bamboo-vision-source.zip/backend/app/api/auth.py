"""认证路由：注册、登录、改密、获取当前用户。"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.deps.auth import get_current_user
from app.models import User
from app.schemas.auth import (
    ChangePasswordRequest,
    LoginRequest,
    RegisterRequest,
    TokenResponse,
    UserInfo,
)
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["认证"])


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(req: RegisterRequest, db: AsyncSession = Depends(get_db)):
    """管理员注册。"""
    try:
        return await auth_service.register_admin(req, db)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.post("/login", response_model=TokenResponse)
async def login(req: LoginRequest, db: AsyncSession = Depends(get_db)):
    """登录（管理员/员工统一入口）。"""
    print(f"[login] 收到请求 username={req.username} ticket={'有' if req.captcha_ticket else '空'} randstr={'有' if req.captcha_randstr else '空'}", flush=True)
    print(f"[login] ticket={req.captcha_ticket!r} randstr={req.captcha_randstr!r}", flush=True)
    try:
        return await auth_service.login(req, db)
    except ValueError as e:
        print(f"[login] 登录失败：{e}", flush=True)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(e))


@router.get("/me", response_model=UserInfo)
async def me(user: User = Depends(get_current_user)):
    """获取当前登录用户信息。"""
    return user


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(
    req: ChangePasswordRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """修改自己的密码。"""
    try:
        await auth_service.change_password(user.id, req.old_password, req.new_password, db)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
