"""API 路由聚合。"""
from fastapi import APIRouter

from app.api import admin, auth, order, price

api_router = APIRouter(prefix="/api")
api_router.include_router(auth.router, tags=["认证"])
api_router.include_router(price.router, tags=["价格配置"])
api_router.include_router(order.router, tags=["订单"])
api_router.include_router(admin.router, tags=["管理员"])
