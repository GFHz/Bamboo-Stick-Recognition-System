"""订单路由。"""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import get_db
from app.deps.auth import get_current_user, require_admin, require_staff
from app.models import User
from app.schemas.order import CountResponse, OrderCreate, OrderOut, OrderPage, OrderRemarkUpdate
from app.services import order_service
from app.services.count_service import CountError, count_bamboo
from app.services.image_service import ImageUploadError, save_upload_image

router = APIRouter(prefix="/orders", tags=["订单"])


@router.post("/count", response_model=CountResponse)
async def count_skewers(
    file: UploadFile = File(...),
    staff: User = Depends(require_staff),
):
    """员工上传图片做竹签计数（不写订单，只返回结果让员工确认）。"""
    try:
        rel_path, abs_path = await save_upload_image(file)
    except ImageUploadError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))

    try:
        count, annotated_path = count_bamboo(
            abs_path,
            enable_preprocess=settings.enable_preprocess,
            preprocess_method=settings.preprocess_method
        )
    except CountError as e:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, str(e))

    annotated_url = None
    if annotated_path:
        # annotated_path 是绝对路径，转成 URL
        from pathlib import Path
        try:
            upload_root = Path(rel_path).parent  # uploads/yyyy/mm/dd
            # annotated_path = abs_dir / f"{stem}_annotated.jpg"
            annotated_name = Path(annotated_path).name
            annotated_url = f"/{upload_root.as_posix()}/{annotated_name}"
        except Exception:
            annotated_url = None

    return CountResponse(
        count=count,
        image_path=rel_path,
        image_url=f"/{rel_path}",
        annotated_image_url=annotated_url,
    )


@router.post("", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
async def create_order(
    req: OrderCreate,
    staff: User = Depends(require_staff),
    db: AsyncSession = Depends(get_db),
):
    """生成订单。"""
    try:
        return await order_service.create_order(staff, req, db)
    except order_service.OrderError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("/me", response_model=OrderPage)
async def my_orders(
    page: int = 1,
    page_size: int = 20,
    status: Optional[int] = None,
    staff: User = Depends(require_staff),
    db: AsyncSession = Depends(get_db),
):
    """员工查看自己的订单。"""
    return await order_service.list_my_orders(staff, page, page_size, status, db)


@router.patch("/{order_id}/remark", response_model=OrderOut)
async def update_remark(
    order_id: int,
    req: OrderRemarkUpdate,
    staff: User = Depends(require_staff),
    db: AsyncSession = Depends(get_db),
):
    """员工修改自己订单的备注。"""
    try:
        return await order_service.update_remark(staff, order_id, req.remark, db)
    except order_service.OrderError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


# ===== 管理员接口 =====
@router.get("", response_model=OrderPage)
async def list_orders(
    page: int = 1,
    page_size: int = 20,
    staff_id: Optional[int] = None,
    status: Optional[int] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """管理员查看本店订单。"""
    return await order_service.list_all_orders(
        admin, page, page_size, staff_id, status, start_date, end_date, db
    )


@router.post("/{order_id}/cancel", response_model=OrderOut)
async def cancel_order(
    order_id: int,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """管理员撤销订单。"""
    try:
        return await order_service.cancel_order_by_admin(order_id, admin, db)
    except order_service.OrderError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
