"""价格配置路由。管理员管理本店单价；员工可查本店当前价。"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.deps.auth import get_current_user, require_admin
from app.models import User
from app.schemas.price import PriceConfigCreate, PriceConfigOut
from app.services import price_service

router = APIRouter(prefix="/prices", tags=["价格配置"])


@router.post("", response_model=PriceConfigOut, status_code=status.HTTP_201_CREATED)
async def set_price(
    req: PriceConfigCreate,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """设置本店竹签单价（立即生效）。"""
    try:
        return await price_service.set_price(admin.id, req, db)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@router.get("", response_model=list[PriceConfigOut])
async def list_prices(
    skewer_type: Optional[str] = None,
    admin: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """列出本店价格历史。"""
    return await price_service.list_prices(admin.id, skewer_type, db)


@router.get("/current", response_model=dict)
async def current_prices(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """查询当前生效竹签单价。

    - 管理员：返回本店价格
    - 员工：返回所属店的价格
    """
    admin_id = user.id if user.role == 1 else user.admin_id
    if admin_id is None:
        return {"bamboo": None}
    bamboo = await price_service.get_effective_price(admin_id, "bamboo", db)
    return {
        "bamboo": bamboo.unit_price if bamboo else None,
    }
