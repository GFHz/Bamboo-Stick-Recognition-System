"""员工管理 Schema。"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class StaffCreate(BaseModel):
    """新增员工。初始密码统一为 abcd1234，员工首次登录强制改密。"""
    username: str = Field(..., min_length=3, max_length=32, description="工号 3-32 位")
    name: str = Field(..., min_length=1, max_length=32, description="姓名")


class StaffOut(BaseModel):
    id: int
    username: str
    name: str
    role: int
    is_active: int
    must_change_password: int
    model_config = {"from_attributes": True}


class StaffListResponse(BaseModel):
    total: int
    items: list[StaffOut]


class StaffStatusUpdate(BaseModel):
    is_active: int = Field(..., ge=0, le=1, description="1=启用, 0=停用")
