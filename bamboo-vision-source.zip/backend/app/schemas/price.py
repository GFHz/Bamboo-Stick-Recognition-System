"""价格配置 Schema。"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, Field, field_validator


class PriceConfigCreate(BaseModel):
    skewer_type: str = Field(default="bamboo", description="固定为 bamboo")
    unit_price: Decimal = Field(..., gt=0, le=1000, description="单价（元）")

    @field_validator("skewer_type")
    @classmethod
    def valid_type(cls, v: str) -> str:
        v = v.lower().strip()
        if v not in ("bamboo",):
            raise ValueError("skewer_type 必须是 bamboo")
        return v


class PriceConfigOut(BaseModel):
    id: int
    admin_id: int
    skewer_type: str
    unit_price: Decimal
    effective_date: date
    created_at: datetime
    model_config = {"from_attributes": True}


class CurrentPrice(BaseModel):
    """当前生效价格。"""
    skewer_type: str
    unit_price: Decimal
    effective_date: date
