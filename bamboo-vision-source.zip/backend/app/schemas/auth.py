"""认证相关 Pydantic Schema。"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator


# ============ 请求 ============
class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=32, description="账号")
    password: str = Field(..., min_length=1, max_length=32, description="密码")
    role: str = Field("staff", description="登录身份：admin=管理员入口，staff=员工入口")
    captcha_ticket: Optional[str] = Field(None, description="滑块验证码 ticket，dev 模式可空")
    captcha_randstr: Optional[str] = Field(None, description="滑块验证码随机串")


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=32, description="账号 3-32 位")
    password: str = Field(..., min_length=8, max_length=16, description="密码 8-16 位，需含字母和数字")
    password_confirm: str = Field(..., description="确认密码")
    name: str = Field(..., min_length=1, max_length=32, description="真实姓名")
    captcha_ticket: Optional[str] = None
    captcha_randstr: Optional[str] = None

    @field_validator("password_confirm")
    @classmethod
    def passwords_match(cls, v, info):
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("两次密码不一致")
        return v


class ChangePasswordRequest(BaseModel):
    old_password: str = Field(..., min_length=1, max_length=32)
    new_password: str = Field(..., min_length=8, max_length=16, description="新密码 8-16 位")
    new_password_confirm: str = Field(...)

    @field_validator("new_password_confirm")
    @classmethod
    def passwords_match(cls, v, info):
        if "new_password" in info.data and v != info.data["new_password"]:
            raise ValueError("两次新密码不一致")
        return v


# ============ 响应 ============
class UserInfo(BaseModel):
    id: int
    username: str
    name: str
    role: int
    must_change_password: bool
    created_at: datetime
    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserInfo
