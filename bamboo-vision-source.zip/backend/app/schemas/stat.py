"""统计 Schema。"""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from pydantic import BaseModel


class DailyStat(BaseModel):
    date: date
    order_count: int
    total_amount: Decimal


class StatRange(BaseModel):
    """按日期范围统计。"""
    start_date: date
    end_date: date
    total_orders: int
    total_amount: Decimal
    daily: list[DailyStat]


class DashboardSummary(BaseModel):
    """首页汇总。"""
    today_orders: int
    today_amount: Decimal
    month_orders: int
    month_amount: Decimal
    year_orders: int
    year_amount: Decimal
    # 趋势：最近 30 天
    daily_trend: list[DailyStat]
