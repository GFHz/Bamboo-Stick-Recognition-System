"""订单 Schema。"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, Field


class CountRequest(BaseModel):
    """上传图片做计数。"""


class CountResponse(BaseModel):
    """计数结果（生成订单前返回前端确认）。"""
    count: int = Field(..., ge=0, description="识别出的竹签数量")
    image_path: Optional[str] = Field(None, description="压缩图相对路径")
    image_url: Optional[str] = Field(None, description="可访问 URL")
    annotated_image_url: Optional[str] = Field(None, description="标注图 URL")


class OrderCreate(BaseModel):
    """生成订单（确认后调用）。"""
    bamboo_count: int = Field(..., ge=0, le=10000, description="竹签数量（可手动改）")
    image_path: Optional[str] = Field(None, description="计数时返回的 image_path")
    remark: Optional[str] = Field(None, max_length=200, description="备注")


class OrderRemarkUpdate(BaseModel):
    remark: Optional[str] = Field(None, max_length=200)


class OrderOut(BaseModel):
    id: int
    order_no: str
    staff_id: int
    staff_name: Optional[str] = None
    bamboo_count: int
    unit_price: Decimal
    total_amount: Decimal
    image_url: Optional[str] = None
    remark: Optional[str] = None
    status: int
    created_at: datetime
    cancelled_at: Optional[datetime] = None
    model_config = {"from_attributes": True}


class OrderPage(BaseModel):
    """订单分页结果。"""
    total: int
    page: int
    page_size: int
    items: list[OrderOut]
