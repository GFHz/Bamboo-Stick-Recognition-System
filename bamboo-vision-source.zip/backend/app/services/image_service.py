"""图片上传与压缩服务。

- 接收上传文件，校验类型/大小
- 压缩为 JPEG（quality 85），长边不超过 1920
- 存到 uploads/yyyy/mm/dd/ 目录
- 返回相对路径（用于 URL 访问）和绝对路径
"""
from __future__ import annotations

import logging
import uuid
from datetime import date
from io import BytesIO
from pathlib import Path

from fastapi import UploadFile

from app.config import settings

logger = logging.getLogger(__name__)

ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/jpg", "image/png", "image/webp", "image/bmp"}
MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10MB 上传限制
JPEG_QUALITY = 85
MAX_LONG_EDGE = 1920


class ImageUploadError(RuntimeError):
    pass


def _resolve_upload_root() -> Path:
    """返回 uploads 根目录（绝对路径）。

    settings.upload_dir 是相对路径时，相对于 backend/ 目录解析。
    """
    p = Path(settings.upload_dir)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[2] / p  # backend/uploads
    p.mkdir(parents=True, exist_ok=True)
    return p


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


async def save_upload_image(upload: UploadFile) -> tuple[str, Path]:
    """保存并压缩上传图片。

    Returns:
        (相对路径用于 URL 访问, 绝对路径用于后续处理)
        相对路径形如: uploads/2026/06/29/xxx.jpg
    """
    if upload.content_type not in ALLOWED_CONTENT_TYPES:
        raise ImageUploadError(f"不支持的图片类型: {upload.content_type}")

    raw = await upload.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise ImageUploadError(f"图片大小超过限制（{MAX_UPLOAD_BYTES // 1024 // 1024}MB）")

    try:
        from PIL import Image
    except ImportError:
        raise ImageUploadError("服务器未安装 Pillow")

    try:
        img = Image.open(BytesIO(raw))
    except Exception as e:
        raise ImageUploadError(f"图片解码失败: {e}") from e

    if img.mode != "RGB":
        img = img.convert("RGB")

    # 长边缩放
    w, h = img.size
    long_edge = max(w, h)
    if long_edge > MAX_LONG_EDGE:
        scale = MAX_LONG_EDGE / long_edge
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

    # 按日期分目录
    today = date.today()
    sub_dir = _resolve_upload_root() / f"{today.year:04d}" / f"{today.month:02d}" / f"{today.day:02d}"
    _ensure_dir(sub_dir)

    filename = f"{uuid.uuid4().hex}.jpg"
    abs_path = sub_dir / filename
    rel_path = f"uploads/{today.year:04d}/{today.month:02d}/{today.day:02d}/{filename}"

    img.save(abs_path, "JPEG", quality=JPEG_QUALITY, optimize=True)
    logger.info("[upload] 保存图片 %s (%.1fKB)", rel_path, abs_path.stat().st_size / 1024)
    return rel_path, abs_path


def get_abs_path(rel_path: str) -> Path:
    """根据相对路径反查绝对路径。

    rel_path 形如: uploads/2026/06/29/xxx.jpg
    """
    root = _resolve_upload_root()  # backend/uploads
    # rel_path 去掉前缀 'uploads/'
    if rel_path.startswith("uploads/"):
        return root / rel_path[len("uploads/"):]
    return root.parent / rel_path


def delete_image(rel_path: str) -> None:
    """删除图片文件（撤销订单时调用）。"""
    try:
        p = get_abs_path(rel_path)
        if p.exists():
            p.unlink()
            logger.info("[upload] 删除图片 %s", rel_path)
    except Exception as e:
        logger.warning("[upload] 删除图片失败 %s: %s", rel_path, e)
