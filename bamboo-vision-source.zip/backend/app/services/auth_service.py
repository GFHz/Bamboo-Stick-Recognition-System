"""认证服务：注册、登录、改密。"""
from __future__ import annotations

from typing import Optional

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.jwt import create_access_token
from app.core.security import hash_password, is_strong_password, verify_password
from app.models import User
from app.schemas.auth import LoginRequest, RegisterRequest, TokenResponse, UserInfo
from app.services.captcha_service import verify_captcha


async def register_admin(req: RegisterRequest, db: AsyncSession) -> TokenResponse:
    """管理员注册。"""
    if not is_strong_password(req.password):
        raise ValueError("密码强度不足：8-16 位，需包含字母和数字")

    # 校验滑块验证码
    if not await verify_captcha(req.captcha_ticket, req.captcha_randstr):
        raise ValueError("滑块验证未通过，请重试")

    # 检查用户名是否已存在
    existing = await db.execute(select(User).where(User.username == req.username))
    if existing.scalar_one_or_none() is not None:
        raise ValueError("账号已存在")

    user = User(
        username=req.username,
        password_hash=hash_password(req.password),
        name=req.name,
        role=1,  # 管理员
        is_active=1,
        must_change_password=0,
    )
    db.add(user)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise ValueError("账号已存在")
    await db.refresh(user)

    token = create_access_token(user.id, {"role": user.role, "username": user.username})
    return TokenResponse(access_token=token, user=UserInfo.model_validate(user))


async def login(req: LoginRequest, db: AsyncSession) -> TokenResponse:
    """统一登录入口（管理员/员工）。"""
    # 校验滑块验证码（在账号密码校验之前，避免泄漏账号是否存在）
    if not await verify_captcha(req.captcha_ticket, req.captcha_randstr):
        raise ValueError("滑块验证未通过，请重试")

    result = await db.execute(select(User).where(User.username == req.username))
    user = result.scalar_one_or_none()
    if user is None or not verify_password(req.password, user.password_hash):
        raise ValueError("账号或密码错误")
    if user.deleted_at is not None:
        raise ValueError("账号不存在")
    if user.is_active != 1:
        raise ValueError("账号已停用")

    # 登录入口与账号角色必须匹配：管理员账号只能从管理员入口登录，员工账号只能从员工入口登录
    if req.role == "admin" and user.role != 1:
        raise ValueError("该账号不是管理员，请到员工登录入口")
    if req.role == "staff" and user.role != 2:
        raise ValueError("该账号不是员工，请到管理员登录入口")

    token = create_access_token(user.id, {"role": user.role, "username": user.username})
    return TokenResponse(access_token=token, user=UserInfo.model_validate(user))


async def change_password(
    user_id: int, old_password: str, new_password: str, db: AsyncSession
) -> None:
    """修改自己的密码。"""
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise ValueError("用户不存在")
    if not verify_password(old_password, user.password_hash):
        raise ValueError("原密码错误")
    if not is_strong_password(new_password):
        raise ValueError("新密码强度不足：8-16 位，需包含字母和数字")

    user.password_hash = hash_password(new_password)
    user.must_change_password = 0
    await db.commit()
