"""员工管理服务。每个管理员只能管理本店员工。"""
from __future__ import annotations

from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import hash_password
from app.models import AuditLog, User
from app.schemas.staff import StaffCreate, StaffListResponse, StaffOut


class StaffError(RuntimeError):
    pass


async def create_staff(req: StaffCreate, admin: User, db: AsyncSession) -> StaffOut:
    """新增员工。绑定到当前管理员/店。初始密码统一为 abcd1234，首次登录强制改密。"""
    existing = await db.execute(select(User).where(User.username == req.username))
    if existing.scalar_one_or_none() is not None:
        raise StaffError("工号已存在")

    staff = User(
        username=req.username,
        name=req.name,
        password_hash=hash_password("abcd1234"),
        role=2,
        admin_id=admin.id,
        is_active=1,
        must_change_password=1,
    )
    db.add(staff)
    await db.commit()
    await db.refresh(staff)

    db.add(AuditLog(
        user_id=admin.id,
        action="create_employee",
        detail=f"管理员 {admin.username} 新增员工 {staff.username}({staff.name})，初始密码 abcd1234",
    ))
    await db.commit()
    return StaffOut.model_validate(staff)


async def list_staffs(
    admin: User,
    page: int = 1,
    page_size: int = 20,
    keyword: Optional[str] = None,
    db: AsyncSession | None = None,
) -> StaffListResponse:
    """本店员工列表（含分页和搜索，排除已软删除）。"""
    stmt = select(User).where(
        User.role == 2,
        User.admin_id == admin.id,
        User.deleted_at.is_(None),
    )
    if keyword:
        kw = f"%{keyword}%"
        stmt = stmt.where((User.username.like(kw)) | (User.name.like(kw)))

    cnt_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(cnt_stmt)).scalar_one()

    stmt = stmt.order_by(User.id.desc()).offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(stmt)
    items = [StaffOut.model_validate(u) for u in result.scalars().all()]
    return StaffListResponse(total=total, items=items)


async def delete_staff(staff_id: int, admin: User, db: AsyncSession) -> None:
    """软删除本店员工（保留订单关联，员工从列表消失）。"""
    from datetime import datetime

    result = await db.execute(select(User).where(User.id == staff_id))
    staff = result.scalar_one_or_none()
    if staff is None:
        raise StaffError("员工不存在")
    if staff.role != 2:
        raise StaffError("只能删除员工账号")
    if staff.admin_id != admin.id:
        raise StaffError("无权操作其他店的员工")

    staff.deleted_at = datetime.now()
    staff.is_active = 0
    staff.username = f"deleted_{staff.id}_{staff.username}"
    db.add(AuditLog(
        user_id=admin.id,
        action="delete_employee",
        detail=f"管理员 {admin.username} 删除员工 {staff.username}({staff.name})",
    ))
    await db.commit()


async def toggle_staff_status(staff_id: int, is_active: int, admin: User, db: AsyncSession) -> StaffOut:
    """启用/停用本店员工账号。"""
    result = await db.execute(select(User).where(User.id == staff_id))
    staff = result.scalar_one_or_none()
    if staff is None:
        raise StaffError("员工不存在")
    if staff.role != 2:
        raise StaffError("只能操作员工账号")
    if staff.admin_id != admin.id:
        raise StaffError("无权操作其他店的员工")

    staff.is_active = is_active
    db.add(AuditLog(
        user_id=admin.id,
        action="toggle_employee_status",
        detail=f"管理员 {admin.username} {'启用' if is_active else '停用'}员工 {staff.username}",
    ))
    await db.commit()
    await db.refresh(staff)
    return StaffOut.model_validate(staff)
