"""图片预处理服务：裁剪出竹签的主要区域，提高YOLO检测精度。

使用多种策略：
1. 边缘检测找到主要轮廓区域
2. 颜色分割定位竹签集中区域
3. 基于亮度/对比度的自适应裁剪
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class PreprocessError(RuntimeError):
    """预处理异常。"""
    pass


def detect_roi_by_contour(image_path: str | Path, min_area_ratio: float = 0.1) -> Optional[Tuple[int, int, int, int]]:
    """通过轮廓检测找到感兴趣区域（ROI）。

    Args:
        image_path: 图片路径
        min_area_ratio: 最小区域占比，相对于整图面积

    Returns:
        (x1, y1, x2, y2) 裁剪框坐标，None表示使用原图
    """
    try:
        import cv2
        import numpy as np

        img = cv2.imread(str(image_path))
        if img is None:
            return None

        h, w = img.shape[:2]

        # 转灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 高斯模糊去噪
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Canny边缘检测
        edges = cv2.Canny(blurred, 50, 150)

        # 形态学操作，连接断开的边缘
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
        closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

        # 找轮廓
        contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if not contours:
            return None

        # 找到最大的轮廓
        max_contour = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(max_contour)

        # 如果最大区域太小，不裁剪
        if area < (w * h * min_area_ratio):
            return None

        # 获取轮廓的外接矩形
        x, y, bw, bh = cv2.boundingRect(max_contour)

        # 扩展裁剪框（增加10%边距）
        margin_x = int(bw * 0.1)
        margin_y = int(bh * 0.1)

        x1 = max(0, x - margin_x)
        y1 = max(0, y - margin_y)
        x2 = min(w, x + bw + margin_x)
        y2 = min(h, y + bh + margin_y)

        logger.info(f"[preprocess] 轮廓检测ROI: {x1},{y1},{x2},{y2} (原图{w}x{h})")
        return (x1, y1, x2, y2)

    except Exception as e:
        logger.warning(f"[preprocess] 轮廓检测失败: {e}")
        return None


def detect_roi_by_color(image_path: str | Path, color_range: str = "bamboo") -> Optional[Tuple[int, int, int, int]]:
    """通过颜色分割找到感兴趣区域。

    Args:
        image_path: 图片路径
        color_range: 颜色范围预设（"bamboo"=竹签颜色，"warm"=暖色调）

    Returns:
        (x1, y1, x2, y2) 裁剪框坐标，None表示使用原图
    """
    try:
        import cv2
        import numpy as np

        img = cv2.imread(str(image_path))
        if img is None:
            return None

        h, w = img.shape[:2]

        # 转HSV颜色空间
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # 竹签颜色范围（偏黄棕色）
        if color_range == "bamboo":
            # 竹签通常是淡黄色到棕色
            lower = np.array([10, 30, 50])    # 低饱和度，亮度适中
            upper = np.array([35, 255, 255])  # 黄棕色范围
        else:
            # 默认暖色调
            lower = np.array([0, 30, 50])
            upper = np.array([50, 255, 255])

        # 颜色掩码
        mask = cv2.inRange(hsv, lower, upper)

        # 形态学操作去噪
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # 找轮廓
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if not contours:
            return None

        # 合并所有轮廓的边界框
        all_points = np.vstack(contours)
        x, y, bw, bh = cv2.boundingRect(all_points)

        # 扩展裁剪框
        margin_x = int(bw * 0.1)
        margin_y = int(bh * 0.1)

        x1 = max(0, x - margin_x)
        y1 = max(0, y - margin_y)
        x2 = min(w, x + bw + margin_x)
        y2 = min(h, y + bh + margin_y)

        logger.info(f"[preprocess] 颜色分割ROI: {x1},{y1},{x2},{y2} (原图{w}x{h})")
        return (x1, y1, x2, y2)

    except Exception as e:
        logger.warning(f"[preprocess] 颜色分割失败: {e}")
        return None


def crop_image(image_path: str | Path, roi: Tuple[int, int, int, int], output_path: Optional[str | Path] = None) -> Path:
    """裁剪图片到指定区域。

    Args:
        image_path: 原图路径
        roi: (x1, y1, x2, y2) 裁剪区域
        output_path: 输出路径，None则覆盖原图

    Returns:
        裁剪后的图片路径
    """
    try:
        import cv2

        img = cv2.imread(str(image_path))
        if img is None:
            raise PreprocessError(f"无法读取图片: {image_path}")

        x1, y1, x2, y2 = roi
        cropped = img[y1:y2, x1:x2]

        if output_path is None:
            output_path = image_path
        else:
            output_path = Path(output_path)

        cv2.imwrite(str(output_path), cropped)
        logger.info(f"[preprocess] 图片裁剪完成: {output_path}")
        return Path(output_path)

    except Exception as e:
        raise PreprocessError(f"图片裁剪失败: {e}") from e


def preprocess_image(
    image_path: str | Path,
    method: str = "auto",
    min_area_ratio: float = 0.1,
    enable_crop: bool = True
) -> Tuple[Path, Optional[Tuple[int, int, int, int]]]:
    """预处理图片：检测并裁剪出主要区域。

    Args:
        image_path: 图片路径
        method: 检测方法 ("auto"=自动选择, "contour"=轮廓检测, "color"=颜色分割, "none"=不裁剪)
        min_area_ratio: 最小区域占比
        enable_crop: 是否启用裁剪

    Returns:
        (处理后的图片路径, 裁剪框坐标) 裁剪框为None表示未裁剪
    """
    image_path = Path(image_path)

    if not enable_crop or method == "none":
        logger.info(f"[preprocess] 预处理禁用，使用原图: {image_path}")
        return image_path, None

    roi = None

    # 自动选择最佳方法
    if method == "auto":
        # 先尝试轮廓检测
        roi = detect_roi_by_contour(image_path, min_area_ratio)

        # 如果轮廓检测效果不好，尝试颜色分割
        if roi is None:
            roi = detect_roi_by_color(image_path)

    elif method == "contour":
        roi = detect_roi_by_contour(image_path, min_area_ratio)

    elif method == "color":
        roi = detect_roi_by_color(image_path)

    # 如果没有检测到有效区域，返回原图
    if roi is None:
        logger.info(f"[preprocess] 未检测到有效裁剪区域，使用原图: {image_path}")
        return image_path, None

    # 执行裁剪
    try:
        # 生成裁剪后的临时文件路径
        cropped_path = image_path.with_name(f"{image_path.stem}_cropped{image_path.suffix}")
        result_path = crop_image(image_path, roi, cropped_path)
        return result_path, roi
    except Exception as e:
        logger.warning(f"[preprocess] 裁剪失败，使用原图: {e}")
        return image_path, None
