"""腾讯云滑块验证码（Captcha）票据校验。

使用官方 API：DescribeCaptchaResult
- 接口域名：captcha.tencentcloudapi.com
- Action: DescribeCaptchaResult
- CaptchaType: 9（固定）
- 需 TC3-HMAC-SHA256 签名（用 SecretId/SecretKey）
- 文档：https://cloud.tencent.com/document/product/1110/36926

前端集成方式：用户滑动滑块后获得 ticket + randstr，传给后端校验。
"""
from __future__ import annotations

import logging
from typing import Optional

from app.config import settings

logger = logging.getLogger(__name__)

# 简易内存缓存：ticket 一次性使用，校验过的 ticket 不允许复用
_verified_tickets: set[str] = set()


async def verify_captcha(ticket: Optional[str], randstr: Optional[str], user_ip: str = "") -> bool:
    """校验滑块验证码票据。

    Args:
        ticket: 前端滑块成功后返回的票据
        randstr: 前端滑块返回的随机串
        user_ip: 用户 IP（用于风控，可选）

    Returns:
        True=校验通过；False=校验失败
    """
    # 未配置密钥时，dev 模式放行（方便本地无网络测试）
    if not settings.tencent_cap_cap_app_id or not settings.tencent_cap_app_secret_key:
        logger.warning("[captcha] 未配置 CaptchaAppId/AppSecretKey，dev 模式放行")
        return True

    if not ticket or not randstr:
        return False

    # 防重放
    if ticket in _verified_tickets:
        logger.warning("[captcha] ticket 已被使用过：%s", ticket[:16])
        return False

    # 调用腾讯云官方 DescribeCaptchaResult 接口
    try:
        # 延迟导入，避免无 SDK 时整个模块加载失败
        import json
        from tencentcloud.common import credential
        from tencentcloud.common.profile.client_profile import ClientProfile
        from tencentcloud.common.profile.http_profile import HttpProfile
        from tencentcloud.captcha.v20190722 import captcha_client, models

        cred = credential.Credential(
            settings.tencent_cap_secret_id,
            settings.tencent_cap_secret_key,
        )
        http_profile = HttpProfile()
        http_profile.endpoint = "captcha.tencentcloudapi.com"
        client_profile = ClientProfile()
        client_profile.httpProfile = http_profile
        client = captcha_client.CaptchaClient(cred, "", client_profile)

        req = models.DescribeCaptchaResultRequest()
        params = {
            "CaptchaType": 9,
            "Ticket": ticket,
            "UserIp": user_ip or "0.0.0.0",
            "Randstr": randstr,
            "CaptchaAppId": int(settings.tencent_cap_cap_app_id),
            "AppSecretKey": settings.tencent_cap_app_secret_key,
        }
        req.from_json_string(json.dumps(params))
        print(f"[captcha] 调用 DescribeCaptchaResult ticket={ticket[:16]}...", flush=True)

        # SDK 是同步接口，放到线程池执行避免阻塞事件循环
        import asyncio
        resp = await asyncio.to_thread(client.DescribeCaptchaResult, req)
        code = resp.CaptchaCode
        msg = resp.CaptchaMsg
        print(f"[captcha] 腾讯云返回：CaptchaCode={code} CaptchaMsg={msg}", flush=True)

        # CaptchaCode=1 表示验证通过
        ok = (code == 1)
        if not ok:
            print(f"[captcha] 票据校验失败：code={code} msg={msg}", flush=True)
            # dev 模式下：前端滑块已通过（ticket 非空），后端校验失败时放行
            # 避免因配置问题阻塞登录
            if settings.app_env == "dev":
                print(f"[captcha] dev 模式：前端滑块已通过，放行", flush=True)
                return True
            return False
    except Exception as e:
        print(f"[captcha] 校验异常：{type(e).__name__}: {e}", flush=True)
        # dev 模式下网络异常也放行
        if settings.app_env == "dev":
            print(f"[captcha] dev 模式：异常但前端滑块已通过，放行", flush=True)
            return True
        return False

    if ok:
        _verified_tickets.add(ticket)
        # 简单清理：超过 1000 个清空
        if len(_verified_tickets) > 1000:
            _verified_tickets.clear()
    return ok
