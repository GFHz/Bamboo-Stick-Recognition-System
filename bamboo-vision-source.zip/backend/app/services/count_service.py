"""竹签计数服务：基于 YOLO 模型检测竹签数量。

依赖 ultralytics（可选）。若未安装，调用计数接口会返回明确错误。
模型文件位于项目根的 detection/best.pt。
"""
from __future__ import annotations

import logging
from functools import lru_cache
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# 模型文件位置：项目根的 detection/best.pt
_PROJECT_ROOT = Path(__file__).resolve().parents[3]  # backend/app/services -> backend/app -> backend -> project
_MODEL_PATH = _PROJECT_ROOT / "detection" / "best.pt"


class CountError(RuntimeError):
    """计数服务异常。"""


@lru_cache(maxsize=1)
def _load_model():
    """惰性加载 YOLO 模型（单例缓存）。"""
    try:
        from ultralytics import YOLO
    except ImportError as e:
        raise CountError(
            "未安装 ultralytics，请执行: pip install ultralytics"
        ) from e

    if not _MODEL_PATH.exists():
        raise CountError(f"模型文件不存在: {_MODEL_PATH}")

    logger.info("[count] 加载 YOLO 模型: %s", _MODEL_PATH)
    return YOLO(str(_MODEL_PATH))


def count_bamboo(
    image_path: str | Path,
    conf: float = 0.35,
    iou: float = 0.5,
    enable_preprocess: bool = True,
    preprocess_method: str = "auto"
) -> tuple[int, Optional[str]]:
    """对图片做竹签检测。

    Args:
        image_path: 图片绝对路径
        conf: 置信度阈值
        iou: NMS IoU 阈值
        enable_preprocess: 是否启用预处理裁剪
        preprocess_method: 预处理方法 ("auto", "contour", "color", "none")

    Returns:
        (数量, 标注图相对路径)；标注图相对路径为 None 表示未生成。
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise CountError(f"图片不存在: {image_path}")

    # 预处理：裁剪出主要区域
    processed_path = image_path
    roi = None
    if enable_preprocess:
        try:
            from app.services.preprocess_service import preprocess_image
            processed_path, roi = preprocess_image(
                image_path,
                method=preprocess_method,
                enable_crop=True
            )
            logger.info(f"[count] 预处理完成，使用图片: {processed_path}")
        except Exception as e:
            logger.warning(f"[count] 预处理失败，使用原图: {e}")
            processed_path = image_path

    model = _load_model()
    results = model.predict(
        source=str(processed_path),
        save=False,
        save_txt=False,
        conf=conf,
        iou=iou,
        imgsz=640,
        verbose=False,
    )

    boxes = results[0].boxes
    count = int(len(boxes)) if boxes is not None else 0

    # 生成标注图（红色实心圆点标在框中心）
    annotated_path: Optional[str] = None
    try:
        import cv2
        img = cv2.imread(str(processed_path))
        if img is not None and count > 0:
            for box in boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
                cv2.circle(img, (cx, cy), 6, (0, 0, 255), -1)

            annotated_path = str(image_path.with_name(f"{image_path.stem}_annotated{image_path.suffix}"))
            cv2.imwrite(annotated_path, img)

            # 清理临时裁剪文件
            if processed_path != image_path and processed_path.exists():
                processed_path.unlink()
                logger.info(f"[count] 清理临时文件: {processed_path}")
    except ImportError:
        logger.warning("[count] 未安装 opencv-python，跳过标注图生成")

    return count, annotated_path
