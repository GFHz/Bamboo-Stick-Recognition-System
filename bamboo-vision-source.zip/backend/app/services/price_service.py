"""价格配置服务。

业务规则：
- 每个管理员/店维护自己的竹签单价历史
- 修改单价后立即生效（最新一条即为当前价）
- 不影响历史订单（订单存的是当时的 unit_price 快照）
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import PriceConfig
from app.schemas.price import CurrentPrice, PriceConfigCreate, PriceConfigOut


async def set_price(admin_id: int, req: PriceConfigCreate, db: AsyncSession) -> PriceConfigOut:
    """设置本店的竹签单价，立即生效（新增一条记录，最新一条即为当前价）。"""
    cfg = PriceConfig(
        admin_id=admin_id,
        skewer_type=req.skewer_type,
        unit_price=req.unit_price,
        effective_date=date.today(),
    )
    db.add(cfg)
    try:
        await db.commit()
    except Exception:
        await db.rollback()
        raise
    await db.refresh(cfg)
    return PriceConfigOut.model_validate(cfg)


async def list_prices(admin_id: int, skewer_type: str | None, db: AsyncSession, limit: int = 100) -> list[PriceConfigOut]:
    """列出本店价格配置历史（按设置时间倒序）。"""
    stmt = (
        select(PriceConfig)
        .where(PriceConfig.admin_id == admin_id)
        .order_by(desc(PriceConfig.id))
        .limit(limit)
    )
    if skewer_type:
        stmt = stmt.where(PriceConfig.skewer_type == skewer_type)
    result = await db.execute(stmt)
    return [PriceConfigOut.model_validate(r) for r in result.scalars().all()]


async def get_effective_price(
    admin_id: int, skewer_type: str, db: AsyncSession
) -> CurrentPrice | None:
    """查询本店当前生效价格 = 最新一条记录（按 id 倒序）。"""
    stmt = (
        select(PriceConfig)
        .where(
            PriceConfig.admin_id == admin_id,
            PriceConfig.skewer_type == skewer_type,
        )
        .order_by(desc(PriceConfig.id))
        .limit(1)
    )
    result = await db.execute(stmt)
    cfg = result.scalar_one_or_none()
    if cfg is None:
        return None
    return CurrentPrice(
        skewer_type=cfg.skewer_type,
        unit_price=cfg.unit_price,
        effective_date=cfg.effective_date,
    )
