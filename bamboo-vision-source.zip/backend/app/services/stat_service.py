"""统计服务。每个管理员只能看到本店数据。"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Order, User
from app.schemas.stat import DailyStat, DashboardSummary, StatRange


async def _daily_stats(admin_id: int, start: date, end: date, db: AsyncSession) -> list[DailyStat]:
    """聚合 [start, end] 区间内每日有效订单的统计（仅本店）。"""
    stmt = (
        select(
            func.date(Order.created_at).label("d"),
            func.count(Order.id).label("cnt"),
            func.sum(Order.total_amount).label("amt"),
        )
        .where(
            Order.admin_id == admin_id,
            Order.status == 1,
            Order.created_at >= start,
            Order.created_at < end + timedelta(days=1),
        )
        .group_by("d")
        .order_by("d")
    )
    result = await db.execute(stmt)
    rows = {r.d: (r.cnt, r.amt or Decimal("0")) for r in result.all()}

    daily = []
    cur = start
    while cur <= end:
        cnt, amt = rows.get(cur, (0, Decimal("0")))
        daily.append(DailyStat(date=cur, order_count=cnt, total_amount=amt))
        cur += timedelta(days=1)
    return daily


async def get_dashboard(admin: User, db: AsyncSession) -> DashboardSummary:
    """首页汇总（仅本店）。"""
    admin_id = admin.id
    today = date.today()
    month_start = today.replace(day=1)
    year_start = today.replace(month=1, day=1)
    trend_start = today - timedelta(days=29)

    async def _sum(start: date, end: date) -> tuple[int, Decimal]:
        stmt = (
            select(func.count(Order.id), func.sum(Order.total_amount))
            .where(
                Order.admin_id == admin_id,
                Order.status == 1,
                Order.created_at >= start,
                Order.created_at < end,
            )
        )
        r = (await db.execute(stmt)).one()
        return r[0], r[1] or Decimal("0")

    today_orders, today_amount = await _sum(today, today + timedelta(days=1))
    month_orders, month_amount = await _sum(month_start, today + timedelta(days=1))
    year_orders, year_amount = await _sum(year_start, today + timedelta(days=1))

    daily_trend = await _daily_stats(admin_id, trend_start, today, db)
    return DashboardSummary(
        today_orders=today_orders,
        today_amount=today_amount,
        month_orders=month_orders,
        month_amount=month_amount,
        year_orders=year_orders,
        year_amount=year_amount,
        daily_trend=daily_trend,
    )


async def get_stat_range(admin: User, start: date, end: date, db: AsyncSession) -> StatRange:
    """按日期范围统计（仅本店）。"""
    if start > end:
        start, end = end, start
    daily = await _daily_stats(admin.id, start, end, db)
    total_orders = sum(d.order_count for d in daily)
    total_amount = sum(d.total_amount for d in daily)
    return StatRange(
        start_date=start,
        end_date=end,
        total_orders=total_orders,
        total_amount=total_amount,
        daily=daily,
    )


async def export_orders(
    admin: User,
    start: date,
    end: date,
    db: AsyncSession,
) -> bytes:
    """导出本店订单 Excel。返回 bytes。"""
    from io import BytesIO

    from openpyxl import Workbook

    stmt = (
        select(Order, User.username, User.name)
        .join(User, Order.staff_id == User.id, isouter=True)
        .where(
            Order.admin_id == admin.id,
            Order.status == 1,
            Order.created_at >= start,
            Order.created_at < end + timedelta(days=1),
        )
        .order_by(Order.created_at.desc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    wb = Workbook()
    ws = wb.active
    ws.title = "订单"
    ws.append(["订单号", "员工工号", "员工姓名", "竹签数量", "竹签单价", "金额", "备注", "创建时间"])
    for order, staff_username, staff_name in rows:
        ws.append([
            order.order_no,
            staff_username or "",
            staff_name or "",
            order.bamboo_count,
            float(order.unit_price),
            float(order.total_amount),
            order.remark or "",
            order.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        ])

    total_amount = sum(float(o.total_amount) for o, _, _ in rows)
    total_bamboo = sum(o.bamboo_count for o, _, _ in rows)
    ws.append([])
    ws.append(["合计", "", "", total_bamboo, "", total_amount, "", ""])

    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
