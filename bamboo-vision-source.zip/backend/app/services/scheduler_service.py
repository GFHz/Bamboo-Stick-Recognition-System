"""图片过期清理任务。

规则：
- 每天凌晨 3:00 执行
- 删除 uploads/ 下超过 IMAGE_RETENTION_DAYS 天的图片文件
- 数据库中订单的 image_path 不动（订单记录保留），磁盘文件清理
"""
from __future__ import annotations

import logging
import shutil
from datetime import date, timedelta
from pathlib import Path

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import settings
from app.services.image_service import _resolve_upload_root

logger = logging.getLogger(__name__)

_scheduler: AsyncIOScheduler | None = None


async def cleanup_expired_images() -> None:
    """清理超过保留期的图片文件。"""
    root = _resolve_upload_root()
    if not root.exists():
        return

    cutoff = date.today() - timedelta(days=settings.image_retention_days)
    removed = 0

    # uploads/yyyy/mm/dd/ 结构，遍历日期目录
    for year_dir in root.iterdir():
        if not year_dir.is_dir() or not year_dir.name.isdigit():
            continue
        for month_dir in year_dir.iterdir():
            if not month_dir.is_dir() or not month_dir.name.isdigit():
                continue
            for day_dir in month_dir.iterdir():
                if not day_dir.is_dir() or not day_dir.name.isdigit():
                    continue
                try:
                    dir_date = date(int(year_dir.name), int(month_dir.name), int(day_dir.name))
                except ValueError:
                    continue
                if dir_date < cutoff:
                    try:
                        shutil.rmtree(day_dir)
                        removed += 1
                        logger.info("[cleanup] 删除目录 %s", day_dir)
                    except Exception as e:
                        logger.warning("[cleanup] 删除 %s 失败: %s", day_dir, e)
                    # 空的月/年目录也清理
                    try:
                        if not any(month_dir.iterdir()):
                            month_dir.rmdir()
                        if not any(year_dir.iterdir()):
                            year_dir.rmdir()
                    except Exception:
                        pass

    logger.info("[cleanup] 清理完成，删除 %d 个日期目录", removed)


def start_scheduler() -> None:
    """启动定时任务调度器。"""
    global _scheduler
    if _scheduler is not None:
        return
    _scheduler = AsyncIOScheduler()
    # 每天 03:00 执行
    _scheduler.add_job(
        cleanup_expired_images,
        trigger="cron",
        hour=3,
        minute=0,
        id="cleanup_expired_images",
        replace_existing=True,
    )
    _scheduler.start()
    logger.info("[scheduler] 定时任务已启动，每天 03:00 清理过期图片")


async def stop_scheduler() -> None:
    """停止调度器。"""
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
