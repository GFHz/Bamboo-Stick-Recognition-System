"""订单服务。

业务规则：
- 生成订单时锁定当时的单价（不影响历史订单）
- 订单号格式：ORD + yyyyMMdd + 6 位流水（按天自增）
- 撤销订单：status=0, cancelled_at=now, 图片从磁盘删除（image_path 置空）
- 改备注：员工只能改自己的订单备注
- 订单归属：订单的 admin_id = 创建员工所属的管理员/店
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Order, User
from app.schemas.order import OrderCreate, OrderOut, OrderPage
from app.services.image_service import delete_image
from app.services.price_service import get_effective_price


class OrderError(RuntimeError):
    pass


async def _gen_order_no(db: AsyncSession, today: date) -> str:
    """生成订单号：ORD + yyyyMMdd + 6 位流水。"""
    prefix = f"ORD{today.strftime('%Y%m%d')}"
    stmt = select(func.count(Order.id)).where(
        Order.order_no.like(f"{prefix}%")
    )
    result = await db.execute(stmt)
    n = result.scalar_one()
    return f"{prefix}{n + 1:06d}"


async def create_order(
    staff: User,
    req: OrderCreate,
    db: AsyncSession,
) -> OrderOut:
    """员工生成订单。订单归属 = 员工所属管理员/店。"""
    if staff.admin_id is None:
        raise OrderError("员工未绑定到管理员/店，无法生成订单")

    today = date.today()
    bamboo_cfg = await get_effective_price(staff.admin_id, "bamboo", db)
    if bamboo_cfg is None:
        raise OrderError("本店未配置竹签单价，请联系管理员")
    bamboo_price = bamboo_cfg.unit_price

    if req.bamboo_count <= 0:
        raise OrderError("竹签数量必须大于 0")

    total = (bamboo_price * req.bamboo_count).quantize(Decimal("0.01"))

    order_no = await _gen_order_no(db, today)
    order = Order(
        order_no=order_no,
        staff_id=staff.id,
        admin_id=staff.admin_id,
        bamboo_count=req.bamboo_count,
        unit_price=bamboo_price,
        total_amount=total,
        image_path=req.image_path,
        remark=req.remark,
        status=1,
    )
    db.add(order)
    await db.commit()
    await db.refresh(order)

    out = OrderOut.model_validate(order)
    out.staff_name = staff.name
    if order.image_path:
        out.image_url = f"/{order.image_path}"
    return out


async def list_my_orders(
    staff: User,
    page: int = 1,
    page_size: int = 20,
    status_filter: Optional[int] = None,
    db: AsyncSession | None = None,
) -> OrderPage:
    """员工查看自己的订单（分页）。"""
    stmt = select(Order).where(Order.staff_id == staff.id)
    if status_filter is not None:
        stmt = stmt.where(Order.status == status_filter)
    cnt_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(cnt_stmt)).scalar_one()

    stmt = stmt.order_by(Order.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(stmt)
    items = []
    for o in result.scalars().all():
        out = OrderOut.model_validate(o)
        out.staff_name = staff.name
        if o.image_path:
            out.image_url = f"/{o.image_path}"
        items.append(out)
    return OrderPage(total=total, page=page, page_size=page_size, items=items)


async def update_remark(
    staff: User,
    order_id: int,
    remark: Optional[str],
    db: AsyncSession,
) -> OrderOut:
    """员工修改自己订单的备注。"""
    result = await db.execute(select(Order).where(Order.id == order_id))
    order = result.scalar_one_or_none()
    if order is None:
        raise OrderError("订单不存在")
    if order.staff_id != staff.id:
        raise OrderError("无权修改他人订单")
    if order.status != 1:
        raise OrderError("订单已撤销，无法修改")

    order.remark = remark
    await db.commit()
    await db.refresh(order)
    out = OrderOut.model_validate(order)
    out.staff_name = staff.name
    if order.image_path:
        out.image_url = f"/{order.image_path}"
    return out


async def cancel_order_by_admin(
    order_id: int,
    admin: User,
    db: AsyncSession,
) -> OrderOut:
    """管理员撤销订单（仅限本店订单）。"""
    result = await db.execute(select(Order).where(Order.id == order_id))
    order = result.scalar_one_or_none()
    if order is None:
        raise OrderError("订单不存在")
    if order.admin_id != admin.id:
        raise OrderError("无权撤销其他店的订单")
    if order.status != 1:
        raise OrderError("订单已是撤销状态")

    order.status = 0
    order.cancelled_at = datetime.now()
    if order.image_path:
        delete_image(order.image_path)
        order.image_path = None

    from app.models import AuditLog
    db.add(AuditLog(
        user_id=admin.id,
        order_no=order.order_no,
        action="cancel_order",
        detail=f"管理员 {admin.username} 撤销订单 {order.order_no}",
    ))
    await db.commit()
    await db.refresh(order)

    out = OrderOut.model_validate(order)
    out.staff_name = (await db.execute(select(User).where(User.id == order.staff_id))).scalar_one().name
    return out


async def list_all_orders(
    admin: User,
    page: int = 1,
    page_size: int = 20,
    staff_id: Optional[int] = None,
    status_filter: Optional[int] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: AsyncSession | None = None,
) -> OrderPage:
    """管理员查看本店订单（分页+筛选）。"""
    stmt = select(Order, User.name).join(User, Order.staff_id == User.id, isouter=True).where(Order.admin_id == admin.id)
    cnt_stmt = select(func.count(Order.id)).where(Order.admin_id == admin.id)

    if staff_id is not None:
        stmt = stmt.where(Order.staff_id == staff_id)
        cnt_stmt = cnt_stmt.where(Order.staff_id == staff_id)
    if status_filter is not None:
        stmt = stmt.where(Order.status == status_filter)
        cnt_stmt = cnt_stmt.where(Order.status == status_filter)
    if start_date:
        stmt = stmt.where(Order.created_at >= datetime.combine(start_date, datetime.min.time()))
        cnt_stmt = cnt_stmt.where(Order.created_at >= datetime.combine(start_date, datetime.min.time()))
    if end_date:
        stmt = stmt.where(Order.created_at <= datetime.combine(end_date, datetime.max.time()))
        cnt_stmt = cnt_stmt.where(Order.created_at <= datetime.combine(end_date, datetime.max.time()))
    total = (await db.execute(cnt_stmt)).scalar_one()

    stmt = stmt.order_by(Order.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(stmt)
    items = []
    for row in result.all():
        order, staff_name = row
        out = OrderOut.model_validate(order)
        out.staff_name = staff_name
        if order.image_path:
            out.image_url = f"/{order.image_path}"
        items.append(out)
    return OrderPage(total=total, page=page, page_size=page_size, items=items)
