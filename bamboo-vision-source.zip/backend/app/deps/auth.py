"""认证依赖：从请求头解析 JWT，返回当前用户。"""
from __future__ import annotations

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.jwt import decode_access_token
from app.database import get_db
from app.models import User

bearer_scheme = HTTPBearer(auto_error=True)


async def get_current_user(
    cred: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """解析 Bearer Token，返回当前 User 对象。"""
    payload = decode_access_token(cred.credentials)
    if payload is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "无效或过期的令牌")

    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "令牌缺少用户信息")

    result = await db.execute(select(User).where(User.id == int(user_id)))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "用户不存在")
    if user.is_active != 1:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "账号已停用")
    return user


async def require_admin(user: User = Depends(get_current_user)) -> User:
    """要求当前用户是管理员。"""
    if user.role != 1:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "需要管理员权限")
    return user


async def require_staff(user: User = Depends(get_current_user)) -> User:
    """要求当前用户是员工。"""
    if user.role != 2:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "需要员工权限")
    return user
