"""应用配置：通过 pydantic-settings 从 .env 读取。"""
from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # 数据库
    db_host: str = "localhost"
    db_port: int = 3306
    db_user: str = "root"
    db_password: str = ""
    db_name: str = "skewer_count"

    # JWT
    jwt_secret: str = "please-change-me"
    jwt_algorithm: str = "HS256"
    jwt_expire_hours: int = 8

    # 腾讯云验证码
    tencent_cap_secret_id: str = ""
    tencent_cap_secret_key: str = ""
    tencent_cap_appid: str = ""
    tencent_cap_cap_app_id: str = ""
    tencent_cap_app_secret_key: str = ""

    # 图片存储
    upload_dir: str = "./uploads"
    image_retention_days: int = 30

    # 应用
    app_env: str = "dev"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    cors_origins: str = "http://localhost:5173"

    # 图片预处理配置
    enable_preprocess: bool = Field(default=True, alias="ENABLE_PREPROCESS")
    preprocess_method: str = Field(default="auto", alias="PREPROCESS_METHOD")

    @property
    def database_url(self) -> str:
        from urllib.parse import quote_plus
        password = quote_plus(self.db_password)
        return (
            f"mysql+pymysql://{self.db_user}:{password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}?charset=utf8mb4"
        )

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def upload_path(self) -> Path:
        p = Path(self.upload_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p


settings = Settings()
