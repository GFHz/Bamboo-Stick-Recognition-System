"""FastAPI 应用入口。"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api import api_router
from app.config import settings
from app.services.image_service import _resolve_upload_root
from app.services.scheduler_service import start_scheduler, stop_scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动
    print(f"[app] env={settings.app_env} db={settings.db_name}")
    start_scheduler()
    print("[app] 定时任务已启动")
    yield
    # 关闭
    await stop_scheduler()
    print("[app] shutdown")


app = FastAPI(
    title="竹签自动计价系统",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)

# 静态文件：让 /uploads/xxx.jpg 能直接访问
upload_root = _resolve_upload_root()
app.mount("/uploads", StaticFiles(directory=str(upload_root)), name="uploads")


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok"}
