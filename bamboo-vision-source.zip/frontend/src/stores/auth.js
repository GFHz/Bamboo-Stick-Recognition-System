/**
 * 认证状态 store
 */
import { defineStore } from 'pinia'
import { auth as authApi } from '@/api'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('access_token') || '',
    user: JSON.parse(localStorage.getItem('user_info') || 'null'),
  }),

  getters: {
    isLoggedIn: (state) => !!state.token,
    isAdmin: (state) => state.user?.role === 1,
    isStaff: (state) => state.user?.role === 2,
    mustChangePassword: (state) => !!state.user?.must_change_password,
  },

  actions: {
    async login(payload) {
      const data = await authApi.login(payload)
      this.token = data.access_token
      this.user = data.user
      localStorage.setItem('access_token', this.token)
      localStorage.setItem('user_info', JSON.stringify(this.user))
      return data
    },

    async register(payload) {
      return authApi.register(payload)
    },

    async fetchMe() {
      try {
        const user = await authApi.me()
        this.user = user
        localStorage.setItem('user_info', JSON.stringify(user))
        return user
      } catch {
        this.logout()
        return null
      }
    },

    async changePassword(payload) {
      const result = await authApi.changePassword(payload)
      // 改密成功后更新本地状态
      if (this.user) {
        this.user.must_change_password = false
        localStorage.setItem('user_info', JSON.stringify(this.user))
      }
      return result
    },

    logout() {
      this.token = ''
      this.user = null
      localStorage.removeItem('access_token')
      localStorage.removeItem('user_info')
    },
  },
})
