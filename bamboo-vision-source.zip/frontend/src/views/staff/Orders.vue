<template>
  <div class="orders-page fade-in">
    <!-- 顶部筛选 -->
    <div class="filter-bar glass-card">
      <div class="filter-left">
        <el-radio-group v-model="filter.status" @change="loadList">
          <el-radio-button :value="1">有效</el-radio-button>
          <el-radio-button :value="0">已撤销</el-radio-button>
          <el-radio-button :value="null">全部</el-radio-button>
        </el-radio-group>
      </div>
      <div class="filter-right">
        <el-button @click="loadList" :icon="Refresh">刷新</el-button>
        <el-button type="primary" @click="$router.push('/staff/count')" :icon="Plus">
          新订单
        </el-button>
      </div>
    </div>

    <!-- 订单列表 -->
    <div class="orders-list" v-loading="loading">
      <div v-if="list.length === 0 && !loading" class="empty-state glass-card">
        <el-icon class="empty-icon"><DocumentRemove /></el-icon>
        <p>暂无订单</p>
        <el-button type="primary" @click="$router.push('/staff/count')">去生成订单</el-button>
      </div>

      <div v-for="order in list" :key="order.id" class="order-item glass-card">
        <div class="order-main">
          <div class="order-header">
            <span class="order-no">{{ order.order_no }}</span>
            <el-tag :type="order.status === 1 ? 'success' : 'info'" effect="dark" size="small">
              {{ order.status === 1 ? '有效' : '已撤销' }}
            </el-tag>
          </div>
          <div class="order-meta">
            <span class="meta-item">
              <span class="dot dot-bamboo"></span>竹签 {{ order.bamboo_count }}
            </span>
            <span class="meta-item time">{{ formatTime(order.created_at) }}</span>
          </div>
          <div class="order-remark" v-if="order.remark">
            <el-icon><ChatLineRound /></el-icon>
            <span>{{ order.remark }}</span>
          </div>
        </div>

        <div class="order-aside">
          <div class="order-amount">
            <span class="amount-label">金额</span>
            <span class="amount-value gradient-text">¥{{ order.total_amount }}</span>
          </div>
          <div class="order-actions" v-if="order.status === 1">
            <el-button
              v-if="order.image_url"
              size="small"
              type="primary"
              plain
              @click="onViewImage(order)"
              :icon="Picture"
            >原图</el-button>
            <el-button size="small" @click="onEditRemark(order)" :icon="Edit">备注</el-button>
          </div>
          <div class="order-actions" v-else>
            <el-tag type="info" size="small" effect="plain">已撤销</el-tag>
          </div>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination" v-if="total > pageSize">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="loadList"
        />
      </div>
    </div>

    <!-- 改备注弹窗 -->
    <el-dialog v-model="remarkDialog.visible" title="修改备注" width="500" align-center>
      <el-input
        v-model="remarkDialog.value"
        type="textarea"
        :rows="4"
        maxlength="200"
        show-word-limit
        placeholder="请输入备注内容"
      />
      <template #footer>
        <el-button @click="remarkDialog.visible = false">取消</el-button>
        <el-button type="primary" :loading="remarkDialog.loading" @click="saveRemark">保存</el-button>
      </template>
    </el-dialog>

    <!-- 图片预览 -->
    <el-dialog v-model="imageDialog.visible" title="订单原图" width="640" align-center>
      <div class="image-preview">
        <img :src="imageDialog.url" alt="订单图片" v-if="imageDialog.url" />
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import {
  Refresh, Plus, Edit, Picture, ChatLineRound, DocumentRemove,
} from '@element-plus/icons-vue'
import { order as orderApi } from '@/api'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const filter = reactive({ status: 1 })

const remarkDialog = reactive({
  visible: false,
  id: null,
  value: '',
  loading: false,
})

const imageDialog = reactive({
  visible: false,
  url: '',
})

function formatTime(s) {
  if (!s) return ''
  return s.replace('T', ' ').slice(0, 16)
}

async function loadList() {
  loading.value = true
  try {
    const data = await orderApi.mine({
      page: page.value,
      page_size: pageSize,
      status: filter.status,
    })
    list.value = data.items
    total.value = data.total
  } catch {
    // 拦截器已提示
  } finally {
    loading.value = false
  }
}

function onEditRemark(order) {
  remarkDialog.id = order.id
  remarkDialog.value = order.remark || ''
  remarkDialog.visible = true
}

async function saveRemark() {
  remarkDialog.loading = true
  try {
    await orderApi.updateRemark(remarkDialog.id, remarkDialog.value || null)
    ElMessage.success('备注已更新')
    remarkDialog.visible = false
    await loadList()
  } catch {
    // 拦截器已提示
  } finally {
    remarkDialog.loading = false
  }
}

function onViewImage(order) {
  imageDialog.url = order.image_url
  imageDialog.visible = true
}

onMounted(loadList)
</script>

<style scoped>
.orders-page {
  padding: var(--space-md) 0;
}

.filter-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-md) var(--space-lg);
  margin-bottom: var(--space-lg);
}

.orders-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
}

.empty-state {
  text-align: center;
  padding: var(--space-xl);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-md);
}
.empty-icon {
  font-size: 64px;
  color: var(--color-text-muted);
}
.empty-state p {
  color: var(--color-text-muted);
  font-size: 14px;
}

.order-item {
  display: flex;
  justify-content: space-between;
  padding: var(--space-md) var(--space-lg);
  transition: transform 0.2s;
}
.order-item:hover {
  transform: translateY(-2px);
}

.order-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.order-header {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
}
.order-no {
  font-family: var(--font-mono);
  font-size: 14px;
  font-weight: 600;
  color: var(--color-text);
}
.order-meta {
  display: flex;
  gap: var(--space-md);
  font-size: 13px;
  color: var(--color-text-secondary);
  flex-wrap: wrap;
}
.meta-item {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.meta-item.time {
  color: var(--color-text-muted);
  font-size: 12px;
}
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}
.dot-bamboo {
  background: var(--color-primary);
}

.order-remark {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--color-text-muted);
  background: #fffbeb;
  padding: 4px 8px;
  border-radius: var(--radius-sm);
  width: fit-content;
}

.order-aside {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--space-sm);
  padding-left: var(--space-lg);
}

.order-amount {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}
.amount-label {
  font-size: 11px;
  color: var(--color-text-muted);
}
.amount-value {
  font-size: 22px;
  font-weight: 800;
}

.order-actions {
  display: flex;
  gap: 6px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: var(--space-md);
}

.image-preview {
  text-align: center;
}
.image-preview img {
  max-width: 100%;
  border-radius: var(--radius-md);
}

@media (max-width: 768px) {
  .filter-bar {
    flex-direction: column;
    gap: var(--space-sm);
  }
  .order-item {
    flex-direction: column;
    gap: var(--space-md);
  }
  .order-aside {
    flex-direction: row;
    align-items: center;
    padding-left: 0;
    border-top: 1px solid var(--color-border);
    padding-top: var(--space-sm);
  }
}
</style>
