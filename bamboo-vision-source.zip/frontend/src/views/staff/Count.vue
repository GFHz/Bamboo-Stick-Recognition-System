<template>
  <div class="count-page fade-in">
    <!-- 顶部信息卡 -->
    <div class="info-bar glass-card">
      <div class="info-item">
        <div class="info-label">竹签单价（本次会话锁定）</div>
        <div class="info-value">¥ {{ price.bamboo ?? '--' }}</div>
      </div>
      <div class="info-divider"></div>
      <div class="info-item">
        <div class="info-label">员工</div>
        <div class="info-value">{{ user?.name }}</div>
      </div>
    </div>

    <!-- 主体三栏 -->
    <div class="grid">
      <!-- 左：上传/识别 -->
      <div class="card glass-card">
        <div class="card-header">
          <h3><el-icon><Upload /></el-icon> 上传图片识别竹签</h3>
          <p>支持 JPG/PNG，自动调用 AI 模型计数</p>
        </div>

        <el-upload
          ref="uploadRef"
          class="uploader"
          drag
          :auto-upload="true"
          :show-file-list="false"
          :http-request="customUpload"
          accept="image/jpeg,image/png,image/jpg"
        >
          <div v-if="!result && !recognizing" class="upload-empty">
            <el-icon class="upload-icon"><UploadFilled /></el-icon>
            <div class="upload-text">将图片拖到此处，或<em>点击上传</em></div>
            <div class="upload-hint">仅识别竹签，自动计数</div>
          </div>
          <div v-else-if="recognizing" class="upload-loading">
            <el-icon class="rotating"><Loading /></el-icon>
            <div>识别中...</div>
          </div>
          <div v-else class="upload-preview">
            <img :src="result?.image_url || ''" alt="预览" v-if="result?.image_url" />
            <div class="preview-tip">识别完成，可在右侧调整数量</div>
          </div>
        </el-upload>

        <div v-if="result" class="result-actions">
          <el-button @click="onReset">重新上传</el-button>
          <el-button type="primary" @click="showAnnotated = true" :disabled="!result.annotated_image_url">
            查看标注图
          </el-button>
        </div>

        <!-- 标注图弹窗 -->
        <el-dialog v-model="showAnnotated" title="AI 标注图" width="640" align-center>
          <div class="annotated-wrap">
            <img v-if="result?.annotated_image_url" :src="result.annotated_image_url" alt="标注图" />
          </div>
          <div class="annotated-tip">
            红点为 AI 识别到的竹签位置，共
            <strong>{{ result.count }}</strong> 根
          </div>
        </el-dialog>
      </div>

      <!-- 中：数量输入（数字键盘） -->
      <div class="card glass-card">
        <div class="card-header">
          <h3><el-icon><EditPen /></el-icon> 数量确认</h3>
          <p>手动输入或修改签子数量</p>
        </div>

        <!-- 竹签 -->
        <div class="num-block">
          <div class="num-header">
            <span class="num-label">
              <span class="dot dot-bamboo"></span>竹签
            </span>
            <div class="num-display">{{ form.bamboo_count }}</div>
          </div>
          <div v-if="recognizedCount !== null" class="ai-hint">
            <el-icon><InfoFilled /></el-icon> AI识别：{{ recognizedCount }} 根
          </div>
          <NumberPad v-model="form.bamboo_count" :max="10000" :recognized="isRecognized" @manual-edit="onManualEdit" />
        </div>

        <!-- 备注 -->
        <div class="remark-block">
          <div class="num-label">备注（可选）</div>
          <el-input
            v-model="form.remark"
            type="textarea"
            :rows="2"
            maxlength="200"
            show-word-limit
            placeholder="如：桌号 5 号 / 加辣 / 老顾客"
          />
        </div>
      </div>

      <!-- 右：金额预览 + 生成订单 -->
      <div class="card glass-card summary-card">
        <div class="card-header">
          <h3><el-icon><Wallet /></el-icon> 订单预览</h3>
        </div>

        <div class="summary-list">
          <div class="summary-row">
            <span>竹签 {{ form.bamboo_count }} 根 × ¥{{ price.bamboo || 0 }}</span>
            <span>¥ {{ bambooSubtotal }}</span>
          </div>
          <div class="summary-divider"></div>
          <div class="summary-total">
            <span>合计</span>
            <span class="total-amount gradient-text">¥ {{ totalAmount }}</span>
          </div>
        </div>

        <el-button
          type="primary"
          size="large"
          class="submit-btn pulse-glow"
          :loading="submitting"
          :disabled="form.bamboo_count === 0"
          @click="onSubmit"
        >
          {{ submitting ? '生成中...' : '生成订单' }}
        </el-button>

        <div class="summary-tip">
          <el-icon><InfoFilled /></el-icon>
          金额按进入页面时锁定的单价计算，订单生成后不可改价
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Upload, UploadFilled, EditPen, Wallet, InfoFilled, Loading } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import { order as orderApi, price as priceApi } from '@/api'
import NumberPad from '@/components/NumberPad.vue'

const router = useRouter()
const authStore = useAuthStore()
const user = computed(() => authStore.user)

const uploadRef = ref(null)
const recognizing = ref(false)
const submitting = ref(false)
const showAnnotated = ref(false)
const result = ref(null) // { count, image_path, image_url, annotated_image_url }
// 识别状态：recognizedCount 保存AI识别的原始数量（用于提示），isRecognized 标记当前值是否未被手动修改
const recognizedCount = ref(null)
const isRecognized = ref(false)
// 价格快照：进入页面时拉取一次，之后不再刷新
const price = ref({ bamboo: null })

const form = reactive({
  bamboo_count: 0,
  remark: '',
  image_path: null,
})

// 计算金额（按快照价格）
const bambooSubtotal = computed(() => {
  return ((Number(price.value.bamboo) || 0) * form.bamboo_count).toFixed(2)
})
const totalAmount = computed(() => bambooSubtotal.value)

// 加载当前价格（仅进入页面时调用一次，作为本次会话的快照）
async function loadPrice() {
  try {
    const data = await priceApi.current()
    price.value = data
  } catch {}
}

onMounted(loadPrice)

// 自定义上传
async function customUpload({ file }) {
  // 校验大小 10MB
  if (file.size > 10 * 1024 * 1024) {
    ElMessage.error('图片不能超过 10MB')
    return
  }

  recognizing.value = true
  result.value = null
  try {
    const fd = new FormData()
    fd.append('file', file)
    const data = await orderApi.count(fd)
    result.value = data
    // 自动填入识别出的竹签数量，并标记为识别状态
    form.bamboo_count = data.count
    form.image_path = data.image_path
    recognizedCount.value = data.count
    isRecognized.value = true
    ElMessage.success(`识别到 ${data.count} 根竹签`)
  } catch (e) {
    // 拦截器已提示
  } finally {
    recognizing.value = false
  }
}

function onReset() {
  result.value = null
  form.bamboo_count = 0
  form.remark = ''
  form.image_path = null
  recognizedCount.value = null
  isRecognized.value = false
}

function onManualEdit() {
  isRecognized.value = false
}

async function onSubmit() {
  if (form.bamboo_count === 0) {
    ElMessage.warning('请输入竹签数量')
    return
  }
  if (!price.value.bamboo) {
    ElMessage.error('管理员未设置竹签单价')
    return
  }

  try {
    await ElMessageBox.confirm(
      `竹签 ${form.bamboo_count} 根，合计 ¥${totalAmount.value}，确认生成订单？`,
      '确认订单',
      { confirmButtonText: '生成', cancelButtonText: '取消', type: 'info' },
    )
  } catch {
    return
  }

  submitting.value = true
  try {
    const order = await orderApi.create({
      bamboo_count: form.bamboo_count,
      image_path: form.image_path,
      remark: form.remark || null,
    })
    ElMessage.success(`订单已生成：${order.order_no}`)
    // 重置 + 跳转订单列表
    onReset()
    router.push('/staff/orders')
  } catch (e) {
    // 拦截器已提示
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.count-page {
  padding: var(--space-md) 0;
}

.info-bar {
  display: flex;
  align-items: center;
  gap: var(--space-lg);
  padding: var(--space-md) var(--space-lg);
  margin-bottom: var(--space-lg);
}
.info-item {
  display: flex;
  flex-direction: column;
}
.info-label {
  font-size: 12px;
  color: var(--color-text-muted);
  margin-bottom: 4px;
}
.info-value {
  font-size: 18px;
  font-weight: 700;
  color: var(--color-text);
}
.info-divider {
  width: 1px;
  height: 30px;
  background: var(--color-border);
}

.grid {
  display: grid;
  grid-template-columns: 1.2fr 1fr 0.9fr;
  gap: var(--space-lg);
  align-items: start;
}

.card {
  padding: var(--space-lg);
}
.card-header {
  margin-bottom: var(--space-md);
}
.card-header h3 {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
  margin-bottom: 4px;
}
.card-header h3 .el-icon {
  color: var(--color-accent);
}
.card-header p {
  font-size: 12px;
  color: var(--color-text-muted);
}

/* 上传区 */
.uploader {
  width: 100%;
}
.uploader :deep(.el-upload-dragger) {
  background: #f8fafc;
  border: 1px dashed var(--color-border-strong);
  border-radius: var(--radius-md);
  padding: 32px 20px;
  transition: border-color 0.25s;
}
.uploader :deep(.el-upload-dragger:hover) {
  border-color: var(--color-primary);
}
.upload-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.upload-icon {
  font-size: 48px;
  color: var(--color-accent);
}
.upload-text {
  color: var(--color-text-secondary);
  font-size: 14px;
}
.upload-text em {
  color: var(--color-primary);
  font-style: normal;
  margin: 0 4px;
}
.upload-hint {
  color: var(--color-text-muted);
  font-size: 12px;
}
.upload-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  color: var(--color-accent);
}
.rotating {
  font-size: 36px;
  animation: rotate 1.2s linear infinite;
}
@keyframes rotate {
  to { transform: rotate(360deg); }
}
.upload-preview {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.upload-preview img {
  max-width: 100%;
  max-height: 220px;
  border-radius: var(--radius-md);
  object-fit: contain;
}
.preview-tip {
  color: var(--color-success);
  font-size: 13px;
}
.result-actions {
  display: flex;
  gap: var(--space-sm);
  margin-top: var(--space-md);
}
.result-actions .el-button {
  flex: 1;
}

.annotated-wrap {
  padding: var(--space-md) 0;
}
.annotated-wrap img {
  display: block;
  max-width: 100%;
  margin: 0 auto;
  border-radius: var(--radius-md);
}
.annotated-tip {
  margin-top: var(--space-md);
  text-align: center;
  color: var(--color-text-secondary);
  font-size: 14px;
}
.annotated-tip strong {
  color: var(--color-primary);
  font-size: 18px;
  margin: 0 4px;
}

/* 数字输入块 */
.num-block {
  margin-bottom: var(--space-md);
  padding-bottom: var(--space-md);
  border-bottom: 1px solid var(--color-border);
}
.num-block:last-of-type {
  border-bottom: none;
}
.ai-hint {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: var(--color-primary);
  background: #eff6ff;
  padding: 4px 10px;
  border-radius: var(--radius-sm);
  margin-bottom: var(--space-sm);
  border: 1px solid #bfdbfe;
}
.num-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: var(--space-sm);
}
.num-label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: var(--color-text-secondary);
  font-weight: 500;
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.dot-bamboo {
  background: var(--color-primary);
}
.num-display {
  font-family: var(--font-mono);
  font-size: 24px;
  font-weight: 700;
  color: var(--color-accent);
  min-width: 80px;
  text-align: right;
}

.remark-block {
  margin-top: var(--space-md);
}
.remark-block .num-label {
  margin-bottom: 8px;
}

/* 订单预览卡 */
.summary-card {
  display: flex;
  flex-direction: column;
}
.summary-list {
  flex: 1;
  margin-bottom: var(--space-lg);
}
.summary-row {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  font-size: 14px;
  color: var(--color-text-secondary);
}
.summary-divider {
  height: 1px;
  background: var(--color-border);
  margin: var(--space-sm) 0;
}
.summary-total {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
}
.total-amount {
  font-size: 28px;
  font-weight: 800;
}
.submit-btn {
  width: 100%;
  height: 50px;
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 2px;
  border-radius: var(--radius-md);
  margin-bottom: var(--space-md);
}
.summary-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--color-text-muted);
}
.summary-tip .el-icon {
  font-size: 14px;
}

/* 响应式 */
@media (max-width: 1100px) {
  .grid {
    grid-template-columns: 1fr 1fr;
  }
  .summary-card {
    grid-column: 1 / -1;
  }
}
@media (max-width: 768px) {
  .grid {
    grid-template-columns: 1fr;
  }
  .info-bar {
    flex-wrap: wrap;
  }
}
</style>
