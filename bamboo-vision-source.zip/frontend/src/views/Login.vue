<template>
  <div class="auth-page">
    <!-- 背景装饰 -->
    <div class="bg-decor">
      <div class="bg-blob bg-blob-1"></div>
      <div class="bg-blob bg-blob-2"></div>
      <div class="bg-blob bg-blob-3"></div>
    </div>

    <div class="auth-container glass-card fade-in">
      <!-- 左侧品牌区 -->
      <div class="brand-panel">
        <div class="brand-logo">
          <div class="logo-mark">签</div>
        </div>
        <h1 class="brand-title">竹签自动计价系统</h1>
        <p class="brand-tagline">智能识别 · 一键计数 · 精准计费</p>
        <div class="brand-feats">
          <div class="feat-item">
            <el-icon><Camera /></el-icon>
            <span>AI 视觉识别</span>
          </div>
          <div class="feat-item">
            <el-icon><DataLine /></el-icon>
            <span>实时订单统计</span>
          </div>
          <div class="feat-item">
            <el-icon><User /></el-icon>
            <span>多角色管理</span>
          </div>
        </div>
      </div>

      <!-- 右侧表单区 -->
      <div class="form-panel">
        <div class="form-header">
          <h2>欢迎回来</h2>
          <p>请选择身份并登录</p>
        </div>

        <!-- 角色切换 -->
        <div class="role-tabs">
          <button
            v-for="r in roles"
            :key="r.key"
            class="role-tab"
            :class="{ active: form.role === r.key }"
            @click="form.role = r.key"
          >
            <el-icon><component :is="r.icon" /></el-icon>
            <span>{{ r.label }}</span>
          </button>
        </div>

        <el-form ref="formRef" :model="form" :rules="rules" label-position="top" size="large" @submit.prevent>
          <el-form-item prop="username" label="账号">
            <el-input
              v-model="form.username"
              placeholder="请输入账号/工号"
              :prefix-icon="User"
            />
          </el-form-item>

          <el-form-item prop="password" label="密码">
            <el-input
              v-model="form.password"
              type="password"
              placeholder="请输入密码"
              :prefix-icon="Lock"
              show-password
              @keyup.enter="onLogin"
            />
          </el-form-item>

          <el-form-item>
            <el-button
              type="primary"
              class="submit-btn"
              :loading="loading"
              @click="onLogin"
            >
              {{ loading ? '登录中...' : '登 录' }}
            </el-button>
          </el-form-item>
        </el-form>

        <div class="form-footer">
          <span>还没有管理员账号？</span>
          <router-link to="/register">立即注册</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock, Camera, DataLine, UserFilled } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import { showCaptcha } from '@/utils/captcha'

const router = useRouter()
const authStore = useAuthStore()

const formRef = ref(null)
const loading = ref(false)

const roles = [
  { key: 'staff', label: '员工', icon: User },
  { key: 'admin', label: '管理员', icon: UserFilled },
]

const form = reactive({
  role: 'staff',
  username: '',
  password: '',
})

const rules = {
  username: [{ required: true, message: '请输入账号', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
  ],
}

async function onLogin() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch {
    return
  }

  // 滑块验证
  let captcha = { ticket: '', randstr: '' }
  try {
    captcha = await showCaptcha()
  } catch {
    return // 用户取消
  }

  loading.value = true
  try {
    const data = await authStore.login({
      username: form.username,
      password: form.password,
      role: form.role,
      captcha_ticket: captcha.ticket,
      captcha_randstr: captcha.randstr,
    })

    ElMessage.success('登录成功')

    // 必须改密 → 跳改密页
    if (data.user?.must_change_password) {
      router.push('/change-password')
      return
    }

    // 按角色跳转
    const role = data.user?.role
    if (role === 1) {
      router.push('/admin')
    } else {
      router.push('/staff')
    }
  } catch (e) {
    // 错误已在拦截器中提示
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page {
  min-height: 100vh;
  min-height: 100dvh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-lg);
  position: relative;
  overflow: hidden;
}

/* 背景装饰球 */
.bg-decor {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}
.bg-blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
  animation: float 12s ease-in-out infinite;
}
.bg-blob-1 {
  width: 400px;
  height: 400px;
  background: var(--color-primary);
  top: -100px;
  left: -100px;
}
.bg-blob-2 {
  width: 350px;
  height: 350px;
  background: var(--color-accent);
  bottom: -100px;
  right: -50px;
  animation-delay: -4s;
}
.bg-blob-3 {
  width: 300px;
  height: 300px;
  background: var(--color-primary-light);
  top: 40%;
  right: 30%;
  animation-delay: -8s;
}
@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -30px) scale(1.05); }
  66% { transform: translate(-30px, 40px) scale(0.95); }
}

.auth-container {
  position: relative;
  z-index: 1;
  display: flex;
  width: 900px;
  max-width: 100%;
  min-height: 560px;
  overflow: hidden;
}

/* 左侧品牌区 */
.brand-panel {
  flex: 1;
  padding: var(--space-xl);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #eff6ff, #e0f2fe);
  border-right: 1px solid var(--color-border);
}

.brand-logo {
  margin-bottom: var(--space-lg);
}
.logo-mark {
  width: 80px;
  height: 80px;
  border-radius: 24px;
  background: var(--gradient-fire);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 38px;
  font-weight: 900;
  color: #fff;
  box-shadow: var(--shadow-glow);
  animation: pulse-glow 3s ease-in-out infinite;
}

.brand-title {
  font-size: 32px;
  font-weight: 800;
  color: var(--color-text);
  margin-bottom: var(--space-sm);
  letter-spacing: 2px;
}
.brand-tagline {
  color: var(--color-text-secondary);
  font-size: 14px;
  margin-bottom: var(--space-xl);
  letter-spacing: 1px;
}

.brand-feats {
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
  width: 100%;
  max-width: 240px;
}
.feat-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 16px;
  background: #f8fafc;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  color: var(--color-text-secondary);
  font-size: 14px;
  transition: all 0.25s;
}
.feat-item:hover {
  background: #eff6ff;
  color: var(--color-primary);
  transform: translateX(4px);
}
.feat-item .el-icon {
  color: var(--color-accent);
  font-size: 18px;
}

/* 右侧表单区 */
.form-panel {
  flex: 1;
  padding: var(--space-xl);
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-header {
  margin-bottom: var(--space-lg);
  text-align: center;
}
.form-header h2 {
  font-size: 26px;
  font-weight: 700;
  color: var(--color-text);
  margin-bottom: 6px;
}
.form-header p {
  color: var(--color-text-muted);
  font-size: 13px;
}

.role-tabs {
  display: flex;
  gap: var(--space-sm);
  margin-bottom: var(--space-lg);
  padding: 4px;
  background: #f1f5f9;
  border-radius: var(--radius-md);
}
.role-tab {
  flex: 1;
  padding: 10px;
  border: none;
  background: transparent;
  color: var(--color-text-muted);
  border-radius: var(--radius-sm);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 14px;
  transition: all 0.25s;
}
.role-tab:hover {
  color: var(--color-text);
}
.role-tab.active {
  background: var(--gradient-primary);
  color: #fff;
  box-shadow: var(--shadow-sm);
}

.submit-btn {
  width: 100%;
  height: 46px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 4px;
  border-radius: var(--radius-md);
}

.form-footer {
  margin-top: var(--space-lg);
  text-align: center;
  color: var(--color-text-muted);
  font-size: 13px;
}
.form-footer a {
  margin-left: 6px;
  font-weight: 600;
}

/* 响应式 */
@media (max-width: 768px) {
  .auth-page {
    align-items: flex-start;
    padding: var(--space-md) var(--space-sm);
  }
  .auth-container {
    flex-direction: column;
    width: 100%;
    min-height: auto;
    margin-top: 4vh;
  }
  /* 品牌区：手机端大幅精简，只保留 logo + 标题 */
  .brand-panel {
    padding: var(--space-md);
    border-right: none;
    border-bottom: 1px solid var(--color-border);
  }
  .brand-logo {
    margin-bottom: var(--space-sm);
  }
  .logo-mark {
    width: 56px;
    height: 56px;
    font-size: 26px;
    border-radius: 16px;
  }
  .brand-title {
    font-size: 22px;
    margin-bottom: 4px;
  }
  .brand-tagline {
    font-size: 12px;
    margin-bottom: 0;
  }
  .brand-feats {
    display: none;
  }
  /* 表单区：紧凑排版，确保键盘弹出时登录按钮可见 */
  .form-panel {
    padding: var(--space-md);
  }
  .form-header {
    margin-bottom: var(--space-md);
  }
  .form-header h2 {
    font-size: 20px;
  }
}
</style>
