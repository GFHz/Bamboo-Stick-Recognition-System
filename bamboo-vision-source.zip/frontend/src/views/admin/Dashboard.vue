<template>
  <div class="dashboard-page fade-in">
    <!-- 统计卡片 -->
    <div class="stat-grid">
      <div class="stat-card glass-card" v-for="card in statCards" :key="card.title">
        <div class="stat-icon" :style="{ background: card.bg }">
          <el-icon><component :is="card.icon" /></el-icon>
        </div>
        <div class="stat-info">
          <div class="stat-label">{{ card.title }}</div>
          <div class="stat-value">¥ {{ card.amount }}</div>
          <div class="stat-sub">{{ card.orders }} 单</div>
        </div>
      </div>
    </div>

    <!-- 趋势图 -->
    <div class="chart-card glass-card">
      <div class="card-header">
        <h3><el-icon><TrendCharts /></el-icon> 近 30 天订单趋势</h3>
        <div class="chart-tabs">
          <button
            v-for="t in tabs"
            :key="t.key"
            class="chart-tab"
            :class="{ active: currentTab === t.key }"
            @click="currentTab = t.key"
          >
            {{ t.label }}
          </button>
        </div>
      </div>
      <div ref="chartRef" class="chart-container" v-loading="loading"></div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'
import { Money, Calendar, Histogram, TrendCharts } from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import { admin as adminApi } from '@/api'

const loading = ref(false)
const summary = ref(null)
const chartRef = ref(null)
let chartInstance = null
const currentTab = ref('amount')

const tabs = [
  { key: 'amount', label: '金额' },
  { key: 'orders', label: '订单数' },
]

const statCards = computed(() => {
  const s = summary.value
  if (!s) {
    return [
      { title: '今日营收', amount: '--', orders: 0, icon: Money, bg: 'var(--gradient-primary)' },
      { title: '本月营收', amount: '--', orders: 0, icon: Calendar, bg: 'var(--gradient-accent)' },
      { title: '本年营收', amount: '--', orders: 0, icon: Histogram, bg: 'linear-gradient(135deg, #06d6a0 0%, #118ab2 100%)' },
    ]
  }
  return [
    { title: '今日营收', amount: s.today_amount, orders: s.today_orders, icon: Money, bg: 'var(--gradient-primary)' },
    { title: '本月营收', amount: s.month_amount, orders: s.month_orders, icon: Calendar, bg: 'var(--gradient-accent)' },
    { title: '本年营收', amount: s.year_amount, orders: s.year_orders, icon: Histogram, bg: 'linear-gradient(135deg, #06d6a0 0%, #118ab2 100%)' },
  ]
})

async function loadSummary() {
  loading.value = true
  try {
    summary.value = await adminApi.dashboard()
    await nextTick()
    renderChart()
  } catch {
    // 拦截器已提示
  } finally {
    loading.value = false
  }
}

function renderChart() {
  if (!chartRef.value || !summary.value) return
  if (!chartInstance) {
    chartInstance = echarts.init(chartRef.value)
  }

  const trend = summary.value.daily_trend
  const dates = trend.map((d) => d.date)
  const amounts = trend.map((d) => Number(d.total_amount))
  const orders = trend.map((d) => d.order_count)

  const isAmount = currentTab.value === 'amount'

  chartInstance.setOption({
    backgroundColor: 'transparent',
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(255, 255, 255, 0.96)',
      borderColor: 'rgba(37, 99, 235, 0.25)',
      borderWidth: 1,
      textStyle: { color: '#1e293b' },
      extraCssText: 'box-shadow: 0 4px 12px rgba(15,23,42,0.12); border-radius: 8px;',
      formatter: (params) => {
        const p = params[0]
        return `${p.axisValue}<br/>${isAmount ? '金额' : '订单数'}：<b style="color:#2563eb">${isAmount ? '¥' + p.value : p.value}</b>`
      },
    },
    xAxis: {
      type: 'category',
      data: dates,
      axisLine: { lineStyle: { color: 'rgba(15, 23, 42, 0.1)' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      splitLine: { lineStyle: { color: 'rgba(15, 23, 42, 0.06)' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    series: [
      {
        data: isAmount ? amounts : orders,
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: {
          width: 3,
          color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
            { offset: 0, color: '#2563eb' },
            { offset: 1, color: '#60a5fa' },
          ]),
        },
        itemStyle: {
          color: '#2563eb',
          borderColor: '#fff',
          borderWidth: 2,
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(37, 99, 235, 0.25)' },
            { offset: 1, color: 'rgba(37, 99, 235, 0.02)' },
          ]),
        },
      },
    ],
  })
}

function onResize() {
  chartInstance?.resize()
}

// 点击图表外部区域时隐藏 tooltip（手机端 tooltip 点击后不会自动消失）
function onDocumentClick(e) {
  if (chartRef.value && !chartRef.value.contains(e.target)) {
    chartInstance?.dispatchAction({ type: 'hideTip' })
  }
}

watch(currentTab, () => renderChart())

onMounted(() => {
  loadSummary()
  window.addEventListener('resize', onResize)
  document.addEventListener('click', onDocumentClick, true)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  document.removeEventListener('click', onDocumentClick, true)
  chartInstance?.dispose()
  chartInstance = null
})
</script>

<style scoped>
.dashboard-page {
  padding: var(--space-md) 0;
}

.stat-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-lg);
  margin-bottom: var(--space-lg);
}

.stat-card {
  display: flex;
  align-items: center;
  gap: var(--space-md);
  padding: var(--space-lg);
}
.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  color: #fff;
  box-shadow: var(--shadow-md);
}
.stat-info {
  flex: 1;
}
.stat-label {
  font-size: 13px;
  color: var(--color-text-muted);
  margin-bottom: 4px;
}
.stat-value {
  font-size: 24px;
  font-weight: 800;
  color: var(--color-text);
  letter-spacing: 1px;
}
.stat-sub {
  font-size: 12px;
  color: var(--color-text-secondary);
  margin-top: 2px;
}

.chart-card {
  padding: var(--space-lg);
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-md);
}
.card-header h3 {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
}
.card-header h3 .el-icon {
  color: var(--color-accent);
}

.chart-tabs {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: #f1f5f9;
  border-radius: var(--radius-md);
}
.chart-tab {
  padding: 6px 14px;
  border: none;
  background: transparent;
  color: var(--color-text-muted);
  border-radius: var(--radius-sm);
  cursor: pointer;
  font-size: 13px;
  transition: all 0.2s;
}
.chart-tab:hover {
  color: var(--color-text);
}
.chart-tab.active {
  background: var(--gradient-primary);
  color: #fff;
}

.chart-container {
  width: 100%;
  height: 360px;
}

@media (max-width: 768px) {
  .stat-grid {
    grid-template-columns: 1fr;
  }
  .chart-container {
    height: 280px;
  }
}
</style>
