<template>
  <div class="staffs-page fade-in">
    <div class="filter-bar glass-card">
      <div class="filter-left">
        <h3 class="page-title"><el-icon><User /></el-icon> 员工管理</h3>
      </div>
      <div class="filter-right">
        <el-button @click="loadList" :icon="Refresh">刷新</el-button>
        <el-button type="primary" @click="onAdd" :icon="Plus">新增员工</el-button>
      </div>
    </div>

    <div class="table-card glass-card">
      <el-table :data="list" v-loading="loading" stripe style="width: 100%">
        <el-table-column prop="username" label="工号" min-width="120" />
        <el-table-column prop="name" label="姓名" min-width="100" />
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.is_active === 1 ? 'success' : 'danger'" effect="dark" size="small">
              {{ row.is_active === 1 ? '启用' : '停用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="密码状态" width="120" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.must_change_password === 1" type="warning" size="small" effect="plain">
              待改密
            </el-tag>
            <span v-else class="ok-tip">已修改</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button
              size="small"
              :type="row.is_active === 1 ? 'warning' : 'success'"
              plain
              @click="onToggleStatus(row)"
            >
              {{ row.is_active === 1 ? '停用' : '启用' }}
            </el-button>
            <el-button type="danger" size="small" plain @click="onDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination" v-if="total > pageSize">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="prev, pager, next, total"
          @current-change="loadList"
        />
      </div>
    </div>

    <!-- 新增员工弹窗 -->
    <el-dialog v-model="dialog.visible" title="新增员工" width="460" align-center>
      <el-form
        ref="formRef"
        :model="dialog.form"
        :rules="rules"
        label-position="top"
        size="large"
      >
        <el-form-item prop="username" label="工号">
          <el-input v-model="dialog.form.username" placeholder="3-32 位字符" :prefix-icon="User" />
        </el-form-item>
        <el-form-item prop="name" label="姓名">
          <el-input v-model="dialog.form.name" placeholder="请输入员工姓名" :prefix-icon="UserFilled" />
        </el-form-item>
        <div class="default-pwd-tip">
          <el-icon class="tip-icon"><InfoFilled /></el-icon>
          <span class="tip-text">
            员工初始密码统一为 <span class="pwd-highlight">abcd1234</span>，首次登录后系统将强制要求修改密码
          </span>
        </div>
      </el-form>
      <template #footer>
        <el-button @click="dialog.visible = false">取消</el-button>
        <el-button type="primary" :loading="dialog.loading" @click="onSubmit">新增</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  User, UserFilled, Plus, Refresh, InfoFilled,
} from '@element-plus/icons-vue'
import { admin as adminApi } from '@/api'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const formRef = ref(null)

const dialog = reactive({
  visible: false,
  loading: false,
  form: { username: '', name: '' },
})

const rules = {
  username: [
    { required: true, message: '请输入工号', trigger: 'blur' },
    { min: 3, max: 32, message: '工号长度 3-32 位', trigger: 'blur' },
  ],
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
}

async function loadList() {
  loading.value = true
  try {
    const data = await adminApi.listStaffs({ page: page.value, page_size: pageSize })
    list.value = data.items
    total.value = data.total
  } catch {
    // 拦截器已提示
  } finally {
    loading.value = false
  }
}

function onAdd() {
  dialog.form = { username: '', name: '' }
  dialog.visible = true
}

async function onSubmit() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch {
    return
  }

  dialog.loading = true
  try {
    await adminApi.createStaff(dialog.form)
    ElMessage.success('员工已添加')
    dialog.visible = false
    await loadList()
  } catch {
    // 拦截器已提示
  } finally {
    dialog.loading = false
  }
}

async function onDelete(row) {
  try {
    await ElMessageBox.confirm(
      `确定删除员工 ${row.name}（${row.username}）？该员工的历史订单将保留。`,
      '删除员工',
      { confirmButtonText: '确认删除', cancelButtonText: '取消', type: 'warning' },
    )
  } catch {
    return
  }
  try {
    await adminApi.deleteStaff(row.id)
    ElMessage.success('员工已删除')
    await loadList()
  } catch {
    // 拦截器已提示
  }
}

async function onToggleStatus(row) {
  const action = row.is_active === 1 ? '停用' : '启用'
  try {
    await ElMessageBox.confirm(`确定${action}员工 ${row.name}？`, '提示', {
      confirmButtonText: action,
      cancelButtonText: '取消',
      type: 'info',
    })
  } catch {
    return
  }
  try {
    // 1=启用, 0=停用
    await adminApi.toggleStaffStatus(row.id, row.is_active === 1 ? 0 : 1)
    ElMessage.success(`已${action}`)
    await loadList()
  } catch {
    // 拦截器已提示
  }
}

import { onMounted } from 'vue'
onMounted(loadList)
</script>

<style scoped>
.staffs-page {
  padding: var(--space-md) 0;
}

.filter-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-md) var(--space-lg);
  margin-bottom: var(--space-lg);
}
.page-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
}
.page-title .el-icon {
  color: var(--color-accent);
}

.table-card {
  padding: var(--space-lg);
}

.ok-tip {
  color: var(--color-success);
  font-size: 12px;
}

.default-pwd-tip {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin-top: 8px;
  padding: 12px 14px;
  font-size: 13px;
  line-height: 1.6;
  color: var(--color-text-secondary);
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: var(--radius-sm);
}
.tip-icon {
  color: var(--color-primary);
  font-size: 16px;
  flex-shrink: 0;
  margin-top: 2px;
}
.tip-text {
  flex: 1;
}
.pwd-highlight {
  color: var(--color-primary);
  font-weight: 700;
  padding: 0 2px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: var(--space-md);
}

@media (max-width: 768px) {
  .filter-bar {
    flex-direction: column;
    gap: var(--space-sm);
    align-items: stretch;
  }
  .filter-right {
    display: flex;
    gap: 8px;
  }
  .filter-right .el-button {
    flex: 1;
  }
  .table-card {
    padding: var(--space-sm);
    overflow-x: auto;
  }
}
</style>
