<template>
  <div class="price-page fade-in">
    <!-- 当前价格 -->
    <div class="current-card glass-card">
      <div class="card-header">
        <h3><el-icon><PriceTag /></el-icon> 当前竹签单价</h3>
        <el-button @click="loadCurrent" :icon="Refresh" text>刷新</el-button>
      </div>
      <div class="price-grid">
        <div class="price-item">
          <div class="price-type">
            <span class="dot dot-bamboo"></span>竹签
          </div>
          <div class="price-value" v-if="current.bamboo">¥ {{ current.bamboo }} / 根</div>
          <div class="price-value empty" v-else>未设置</div>
        </div>
      </div>
      <div class="price-tip">
        <el-icon><InfoFilled /></el-icon>
        修改单价后<b>立即生效</b>，不影响历史订单的金额
      </div>
    </div>

    <!-- 设置新单价 -->
    <div class="set-card glass-card">
      <div class="card-header">
        <h3><el-icon><EditPen /></el-icon> 设置新单价</h3>
      </div>

      <el-form ref="formRef" :model="form" :rules="rules" label-position="top" size="large">
        <div class="form-row">
          <el-form-item prop="skewer_type" label="签子类型">
            <el-select v-model="form.skewer_type" placeholder="请选择" disabled>
              <el-option label="竹签" value="bamboo" />
            </el-select>
          </el-form-item>

          <el-form-item prop="unit_price" label="单价（元）">
            <el-input
              v-model="form.unit_price"
              placeholder="如 0.50"
              :prefix-icon="Money"
              type="text"
              @input="onPriceInput"
            />
          </el-form-item>
        </div>

        <el-form-item>
          <el-button
            type="primary"
            size="large"
            :loading="submitting"
            @click="onSubmit"
            class="submit-btn"
          >
            <el-icon><Check /></el-icon> 确认设置（立即生效）
          </el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 历史价格 -->
    <div class="history-card glass-card">
      <div class="card-header">
        <h3><el-icon><Clock /></el-icon> 价格变更历史</h3>
      </div>

      <el-table :data="history" v-loading="historyLoading" stripe>
        <el-table-column label="单价" width="160">
          <template #default="{ row }">
            <span class="hist-price">¥ {{ row.unit_price }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="created_at" label="设置时间" min-width="200">
          <template #default="{ row }">{{ formatTime(row.created_at) }}</template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import {
  PriceTag, EditPen, Refresh, Money, InfoFilled, Check, Clock,
} from '@element-plus/icons-vue'
import { price as priceApi } from '@/api'

const formRef = ref(null)
const submitting = ref(false)
const historyLoading = ref(false)
const current = ref({ bamboo: null })
const history = ref([])

const form = reactive({
  skewer_type: 'bamboo',
  unit_price: '',
})

const rules = {
  skewer_type: [{ required: true, message: '请选择类型', trigger: 'change' }],
  unit_price: [
    { required: true, message: '请输入单价', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        const n = Number(value)
        if (isNaN(n) || n <= 0) {
          callback(new Error('单价必须是大于 0 的数字'))
        } else if (n > 1000) {
          callback(new Error('单价不能超过 1000 元'))
        } else if (!/^\d+(\.\d{1,2})?$/.test(String(value))) {
          callback(new Error('最多两位小数'))
        } else {
          callback()
        }
      },
      trigger: 'blur',
    },
  ],
}

function onPriceInput(val) {
  // 只允许数字和小数点
  form.unit_price = val.replace(/[^\d.]/g, '')
}

function formatTime(s) {
  if (!s) return ''
  return s.replace('T', ' ').slice(0, 19)
}

async function loadCurrent() {
  try {
    current.value = await priceApi.current()
  } catch {}
}

async function loadHistory() {
  historyLoading.value = true
  try {
    history.value = await priceApi.list({ skewer_type: 'bamboo' })
  } catch {
    // 拦截器已提示
  } finally {
    historyLoading.value = false
  }
}

async function onSubmit() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch {
    return
  }

  submitting.value = true
  try {
    await priceApi.set({
      skewer_type: form.skewer_type,
      unit_price: form.unit_price,
    })
    ElMessage.success(`竹签单价已设置，立即生效`)
    form.unit_price = ''
    await loadCurrent()
    await loadHistory()
  } catch {
    // 拦截器已提示
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadCurrent()
  loadHistory()
})
</script>

<style scoped>
.price-page {
  padding: var(--space-md) 0;
  max-width: 900px;
}

.current-card,
.set-card,
.history-card {
  padding: var(--space-lg);
  margin-bottom: var(--space-lg);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-md);
}
.card-header h3 {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
}
.card-header h3 .el-icon {
  color: var(--color-accent);
}

.price-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--space-lg);
  margin-bottom: var(--space-md);
}
.price-item {
  padding: var(--space-md);
  background: #f8fafc;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}
.price-type {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: var(--color-text-secondary);
  margin-bottom: 8px;
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.dot-bamboo {
  background: var(--color-primary);
}
.price-value {
  font-size: 28px;
  font-weight: 800;
  color: var(--color-accent);
}
.price-value.empty {
  color: var(--color-text-muted);
  font-size: 18px;
  font-weight: 600;
}

.price-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--color-text-secondary);
  padding: var(--space-sm) var(--space-md);
  background: #eff6ff;
  border-radius: var(--radius-sm);
}
.price-tip b {
  color: var(--color-accent);
  margin: 0 4px;
}

.form-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-md);
}

.submit-btn {
  width: 200px;
  height: 46px;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 2px;
}

.hist-price {
  font-weight: 700;
  color: var(--color-accent);
  font-size: 16px;
}

@media (max-width: 768px) {
  .price-grid,
  .form-row {
    grid-template-columns: 1fr;
  }
}
</style>
