<template>
  <div class="stats-page fade-in">
    <!-- 顶部日期筛选 + 导出 -->
    <div class="filter-bar glass-card">
      <div class="filter-left">
        <div class="filter-label-row">
          <span class="filter-label">日期范围</span>
          <span class="range-tip">3年以内</span>
        </div>
        <div class="date-pickers">
          <el-select
            v-model="filterYear"
            placeholder="年份"
            class="date-select"
            @change="onYearChange"
          >
            <el-option v-for="y in yearOptions" :key="y" :label="y + '年'" :value="y" />
          </el-select>
          <el-select
            v-model="filterMonth"
            placeholder="月份"
            class="date-select"
            :disabled="!filterYear"
            @change="onMonthChange"
          >
            <el-option :value="null" label="全部" />
            <el-option
              v-for="m in 12"
              :key="m"
              :label="m + '月'"
              :value="m"
              :disabled="isMonthDisabled(m)"
            />
          </el-select>
          <el-select
            v-model="filterDay"
            placeholder="日期"
            class="date-select"
            :disabled="!filterYear || !filterMonth"
            @change="loadStats"
          >
            <el-option :value="null" label="全部" />
            <el-option
              v-for="d in dayOptions"
              :key="d"
              :label="d + '日'"
              :value="d"
              :disabled="isDayDisabled(d)"
            />
          </el-select>
        </div>
      </div>
      <div class="filter-right">
        <el-button @click="loadStats" :icon="Refresh">刷新</el-button>
        <el-button type="success" @click="onExport" :icon="Download" :loading="exporting">
          导出 Excel
        </el-button>
      </div>
    </div>

    <!-- 汇总 -->
    <div class="summary-grid" v-if="stats">
      <div class="summary-card glass-card">
        <div class="sum-icon" style="background: var(--gradient-primary)">
          <el-icon><ShoppingCart /></el-icon>
        </div>
        <div class="sum-info">
          <div class="sum-label">订单总数</div>
          <div class="sum-value">{{ stats.total_orders }}</div>
        </div>
      </div>
      <div class="summary-card glass-card">
        <div class="sum-icon" style="background: var(--gradient-accent)">
          <el-icon><Money /></el-icon>
        </div>
        <div class="sum-info">
          <div class="sum-label">营收总额</div>
          <div class="sum-value">¥ {{ stats.total_amount }}</div>
        </div>
      </div>
    </div>

    <!-- 趋势图 -->
    <div class="chart-card glass-card">
      <div class="card-header">
        <h3><el-icon><TrendCharts /></el-icon> 每日趋势</h3>
      </div>
      <div ref="chartRef" class="chart-container" v-loading="loading"></div>
    </div>

    <!-- 订单列表 -->
    <div class="orders-card glass-card">
      <div class="card-header">
        <h3><el-icon><Document /></el-icon> 订单明细</h3>
        <div class="filter-tags">
          <el-radio-group v-model="filter.status" @change="loadOrders" size="small">
            <el-radio-button :value="1">有效</el-radio-button>
            <el-radio-button :value="0">已撤销</el-radio-button>
            <el-radio-button :value="null">全部</el-radio-button>
          </el-radio-group>
        </div>
      </div>

      <el-table :data="orders" v-loading="ordersLoading" stripe style="width: 100%">
        <el-table-column prop="order_no" label="订单号" min-width="160" />
        <el-table-column prop="staff_name" label="员工" min-width="80" />
        <el-table-column label="竹签" width="80" align="center">
          <template #default="{ row }">
            <span class="count-tag">{{ row.bamboo_count }}</span>
          </template>
        </el-table-column>
        <el-table-column label="单价" width="100" align="center">
          <template #default="{ row }">
            <div class="price-cell">
              <span>¥{{ row.unit_price }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="金额" width="110" align="right">
          <template #default="{ row }">
            <span class="amount-cell">¥{{ row.total_amount }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" min-width="140" show-overflow-tooltip />
        <el-table-column label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'info'" effect="dark" size="small">
              {{ row.status === 1 ? '有效' : '已撤销' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" width="160">
          <template #default="{ row }">{{ formatTime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button
              v-if="row.status === 1"
              type="danger"
              size="small"
              plain
              @click="onCancel(row)"
            >撤销</el-button>
            <span v-else class="cancelled-tip">已撤销</span>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination" v-if="ordersTotal > pageSize">
        <el-pagination
          v-model:current-page="ordersPage"
          :page-size="pageSize"
          :total="ordersTotal"
          layout="prev, pager, next, total"
          @current-change="loadOrders"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeUnmount, nextTick, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Refresh, Download, ShoppingCart, Money, TrendCharts, Document,
} from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import { admin as adminApi, order as orderApi, auth as authApi } from '@/api'

const loading = ref(false)
const ordersLoading = ref(false)
const exporting = ref(false)
const stats = ref(null)
const orders = ref([])
const ordersTotal = ref(0)
const ordersPage = ref(1)
const pageSize = 20
const chartRef = ref(null)
let chartInstance = null

// 日期筛选：年（必选）/ 月（可选）/ 日（可选，依赖月份）
// 限制：
//   1. 仅可选当前年及前两年（3 年内）
//   2. 不早于开业时间（开业时间 = 当前管理员的创建日期，从数据库动态获取）
//   3. 今天也可以选择和统计
const OPEN_DATE = ref({ year: 2026, month: 1, day: 1 })  // 初始默认值，onMounted 时从 API 获取实际开业时间
const _today = new Date()
const yearOptions = computed(() => {
  const cur = _today.getFullYear()
  const minY = Math.max(OPEN_DATE.value.year, cur - 2)
  const arr = []
  for (let y = minY; y <= cur; y++) arr.push(y)
  return arr
})
const filterYear = ref(yearOptions.value.includes(_today.getFullYear()) ? _today.getFullYear() : yearOptions.value[0])
const filterMonth = ref(null)
const filterDay = ref(null)

// 今天（今天可选，今天以后的日期/月份禁用）
const TODAY = { year: _today.getFullYear(), month: _today.getMonth() + 1, day: _today.getDate() }

// 月份是否禁用：
//   1. 开业前的月份（选开业年时）禁用
//   2. 未来月份（选当年时，晚于当前月的月份）禁用 —— 当前月可选
function isMonthDisabled(m) {
  if (!filterYear.value) return true
  if (filterYear.value === OPEN_DATE.value.year && m < OPEN_DATE.value.month) return true
  if (filterYear.value === TODAY.year && m > TODAY.month) return true
  return false
}
// 日期是否禁用：
//   1. 开业日之前（选开业年+开业月时）禁用
//   2. 今天以后（选当年+当月时，晚于今天的日期）禁用 —— 今天可选
function isDayDisabled(d) {
  if (!filterYear.value || !filterMonth.value) return true
  if (filterYear.value === OPEN_DATE.value.year && filterMonth.value === OPEN_DATE.value.month && d < OPEN_DATE.value.day) return true
  if (filterYear.value === TODAY.year && filterMonth.value === TODAY.month && d > TODAY.day) return true
  return false
}

const dayOptions = computed(() => {
  if (!filterYear.value || !filterMonth.value) return []
  const lastDay = new Date(filterYear.value, filterMonth.value, 0).getDate()
  return Array.from({ length: lastDay }, (_, i) => i + 1)
})

// 由年/月/日推导查询区间（今天也纳入统计）
const dateRange = computed(() => {
  const y = filterYear.value
  if (!y) return null
  if (!filterMonth.value) {
    return [`${y}-01-01`, `${y}-12-31`]
  }
  const m = String(filterMonth.value).padStart(2, '0')
  if (!filterDay.value) {
    const lastDay = new Date(y, filterMonth.value, 0).getDate()
    return [`${y}-${m}-01`, `${y}-${m}-${String(lastDay).padStart(2, '0')}`]
  }
  const d = String(filterDay.value).padStart(2, '0')
  return [`${y}-${m}-${d}`, `${y}-${m}-${d}`]
})

const filter = reactive({ status: 1 })

function onYearChange() {
  filterMonth.value = null
  filterDay.value = null
  loadStats()
}
function onMonthChange() {
  filterDay.value = null
  loadStats()
}

function formatTime(s) {
  if (!s) return ''
  return s.replace('T', ' ').slice(0, 16)
}

async function loadStats() {
  if (!dateRange.value) return
  loading.value = true
  try {
    const [start, end] = dateRange.value
    stats.value = await adminApi.stats({ start_date: start, end_date: end })
    await nextTick()
    renderChart()
    ordersPage.value = 1
    await loadOrders()
  } catch {
    // 拦截器已提示
  } finally {
    loading.value = false
  }
}

async function loadOrders() {
  if (!dateRange.value) return
  ordersLoading.value = true
  try {
    const [start, end] = dateRange.value
    const data = await orderApi.list({
      page: ordersPage.value,
      page_size: pageSize,
      status: filter.status,
      start_date: start,
      end_date: end,
    })
    orders.value = data.items
    ordersTotal.value = data.total
  } catch {
    // 拦截器已提示
  } finally {
    ordersLoading.value = false
  }
}

function renderChart() {
  if (!chartRef.value || !stats.value) return
  if (!chartInstance) {
    chartInstance = echarts.init(chartRef.value)
  }

  const daily = stats.value.daily
  const dates = daily.map((d) => d.date)
  const amounts = daily.map((d) => Number(d.total_amount))
  const ordersData = daily.map((d) => d.order_count)

  chartInstance.setOption({
    backgroundColor: 'transparent',
    grid: { top: 40, right: 50, bottom: 30, left: 60 },
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(255, 255, 255, 0.96)',
      borderColor: 'rgba(37, 99, 235, 0.25)',
      borderWidth: 1,
      textStyle: { color: '#1e293b' },
      extraCssText: 'box-shadow: 0 4px 12px rgba(15,23,42,0.12); border-radius: 8px;',
    },
    legend: {
      data: ['订单数', '金额'],
      textStyle: { color: '#475569' },
      top: 0,
    },
    xAxis: {
      type: 'category',
      data: dates,
      axisLine: { lineStyle: { color: 'rgba(15, 23, 42, 0.1)' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: [
      {
        type: 'value',
        name: '订单',
        nameTextStyle: { color: '#64748b' },
        axisLine: { show: false },
        splitLine: { lineStyle: { color: 'rgba(15, 23, 42, 0.06)' } },
        axisLabel: { color: '#64748b' },
      },
      {
        type: 'value',
        name: '金额',
        nameTextStyle: { color: '#64748b' },
        axisLine: { show: false },
        splitLine: { show: false },
        axisLabel: { color: '#64748b', formatter: '¥{value}' },
      },
    ],
    series: [
      {
        name: '订单数',
        data: ordersData,
        type: 'bar',
        barWidth: 18,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#60a5fa' },
            { offset: 1, color: 'rgba(96, 165, 250, 0.2)' },
          ]),
          borderRadius: [6, 6, 0, 0],
        },
      },
      {
        name: '金额',
        data: amounts,
        type: 'line',
        smooth: true,
        yAxisIndex: 1,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: { width: 3, color: '#f97316' },
        itemStyle: { color: '#f97316', borderColor: '#fff', borderWidth: 2 },
      },
    ],
  })
}

async function onExport() {
  if (!dateRange.value || dateRange.value.length !== 2) return
  exporting.value = true
  try {
    const [start, end] = dateRange.value
    const blob = await adminApi.exportUrl(start, end)
    // 触发下载
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `orders_${start}_${end}.xlsx`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    ElMessage.success('导出成功')
  } catch {
    // 拦截器已提示
  } finally {
    exporting.value = false
  }
}

async function onCancel(order) {
  try {
    await ElMessageBox.confirm(
      `确定撤销订单 ${order.order_no}？撤销后将删除原图，且不可恢复。`,
      '撤销订单',
      { confirmButtonText: '确认撤销', cancelButtonText: '取消', type: 'warning' },
    )
  } catch {
    return
  }
  try {
    await orderApi.cancel(order.id)
    ElMessage.success('订单已撤销')
    await loadOrders()
  } catch {
    // 拦截器已提示
  }
}

function onResize() {
  chartInstance?.resize()
}

onMounted(async () => {
  // 从数据库获取当前管理员的创建日期作为开业时间
  try {
    const me = await authApi.me()
    if (me.created_at) {
      const d = new Date(me.created_at)
      OPEN_DATE.value = { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() }
      // 开业时间更新后，若当前选中的年份不在可选范围内则修正
      if (!yearOptions.value.includes(filterYear.value)) {
        filterYear.value = yearOptions.value[0] || filterYear.value
      }
    }
  } catch {
    // 获取失败则用默认值
  }
  loadStats()
  window.addEventListener('resize', onResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  chartInstance?.dispose()
  chartInstance = null
})
</script>

<style scoped>
.stats-page {
  padding: var(--space-md) 0;
}

.filter-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-md) var(--space-lg);
  margin-bottom: var(--space-lg);
  flex-wrap: wrap;
  gap: var(--space-md);
}
.filter-left {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  flex-wrap: nowrap;
}
.filter-label-row {
  display: flex;
  align-items: center;
  gap: 8px;
  white-space: nowrap;
  flex-shrink: 0;
}
.filter-label {
  color: var(--color-text-secondary);
  font-size: 14px;
  white-space: nowrap;
}
.date-pickers {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: nowrap;
}
.date-select {
  width: 110px;
}
.range-tip {
  font-size: 12px;
  color: var(--color-text-muted);
  white-space: nowrap;
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: var(--space-lg);
  margin-bottom: var(--space-lg);
}
.summary-card {
  display: flex;
  align-items: center;
  gap: var(--space-md);
  padding: var(--space-lg);
}
.sum-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  color: #fff;
  box-shadow: var(--shadow-md);
}
.sum-label {
  font-size: 13px;
  color: var(--color-text-muted);
  margin-bottom: 4px;
}
.sum-value {
  font-size: 28px;
  font-weight: 800;
  color: var(--color-text);
}

.chart-card,
.orders-card {
  padding: var(--space-lg);
  margin-bottom: var(--space-lg);
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-md);
  flex-wrap: wrap;
  gap: var(--space-sm);
}
.card-header h3 {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--color-text);
}
.card-header h3 .el-icon {
  color: var(--color-accent);
}

.chart-container {
  width: 100%;
  height: 320px;
}

.count-tag {
  display: inline-block;
  min-width: 32px;
  padding: 2px 8px;
  border-radius: var(--radius-full);
  background: #eff6ff;
  color: var(--color-primary);
  font-family: var(--font-mono);
  font-weight: 600;
}

.price-cell {
  display: flex;
  flex-direction: column;
  font-size: 12px;
  color: var(--color-text-secondary);
  line-height: 1.4;
}

.amount-cell {
  font-weight: 700;
  color: var(--color-accent);
  font-size: 14px;
}

.cancelled-tip {
  color: var(--color-text-muted);
  font-size: 12px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: var(--space-md);
}

@media (max-width: 768px) {
  .filter-bar {
    flex-direction: column;
    align-items: stretch;
    gap: var(--space-sm);
  }
  .filter-left {
    flex-direction: column;
    align-items: flex-start;
    width: 100%;
    gap: 8px;
  }
  .date-pickers {
    width: 100%;
    gap: 6px;
  }
  .date-select {
    flex: 1;
    width: auto;
    min-width: 0;
  }
  .filter-right {
    width: 100%;
    display: flex;
    gap: 8px;
  }
  .filter-right .el-button {
    flex: 1;
  }
  .summary-grid {
    grid-template-columns: 1fr;
  }
  .chart-container {
    height: 260px;
  }
}
</style>
