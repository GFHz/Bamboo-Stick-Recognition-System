<template>
  <div class="auth-page">
    <div class="bg-decor">
      <div class="bg-blob bg-blob-1"></div>
    </div>

    <div class="auth-card glass-card fade-in">
      <div class="card-header">
        <div class="logo-mark">
          <el-icon><Lock /></el-icon>
        </div>
        <h1>修改密码</h1>
        <p v-if="authStore.mustChangePassword" class="warn-tip">
          <el-icon><WarningFilled /></el-icon>
          首次登录需要修改初始密码后才能使用系统
        </p>
      </div>

      <el-form ref="formRef" :model="form" :rules="rules" label-position="top" size="large">
        <el-form-item prop="old_password" label="原密码">
          <el-input v-model="form.old_password" type="password" placeholder="请输入原密码" :prefix-icon="Lock" show-password />
        </el-form-item>

        <el-form-item prop="new_password" label="新密码">
          <el-input
            v-model="form.new_password"
            type="password"
            placeholder="8-16 位，需含字母和数字"
            :prefix-icon="Lock"
            show-password
          />
        </el-form-item>

        <!-- 密码要求 + 强度 -->
        <div class="pwd-tips">
          <div class="pwd-rules">
            <span class="pwd-rules-label">密码要求：</span>
            <span class="pwd-rule" :class="{ ok: rulesCheck.length }">8-16 位</span>
            <span class="pwd-rule" :class="{ ok: rulesCheck.letter }">含字母</span>
            <span class="pwd-rule" :class="{ ok: rulesCheck.digit }">含数字</span>
          </div>
          <div class="pwd-strength" v-if="form.new_password">
            <div class="strength-bars" :class="`level-${strengthLevel}`">
              <span v-for="i in 3" :key="i" class="bar" :class="{ active: i <= strengthLevel }"></span>
            </div>
            <span class="strength-label" :class="`level-${strengthLevel}`">{{ strengthText }}</span>
          </div>
        </div>

        <el-form-item prop="new_password_confirm" label="确认新密码">
          <el-input
            v-model="form.new_password_confirm"
            type="password"
            placeholder="请再次输入新密码"
            :prefix-icon="Lock"
            show-password
            @keyup.enter="onSubmit"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" class="submit-btn" :loading="loading" @click="onSubmit">
            确认修改
          </el-button>
        </el-form-item>
      </el-form>

      <div class="card-footer" v-if="!authStore.mustChangePassword">
        <router-link to="back">返回</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Lock, WarningFilled } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()
const formRef = ref(null)
const loading = ref(false)

const form = reactive({
  old_password: '',
  new_password: '',
  new_password_confirm: '',
})

// 密码规则实时校验
const rulesCheck = computed(() => ({
  length: form.new_password.length >= 8 && form.new_password.length <= 16,
  letter: /[a-zA-Z]/.test(form.new_password),
  digit: /\d/.test(form.new_password),
}))

// 密码强度三档
const strengthLevel = computed(() => {
  const p = form.new_password
  if (!p) return 0
  if (p.length < 8 || p.length > 16) return 0

  const hasUpper = /[A-Z]/.test(p)
  const hasLower = /[a-z]/.test(p)
  const hasDigit = /\d/.test(p)
  const hasSymbol = /[^A-Za-z0-9]/.test(p)
  const hasLetter = hasUpper || hasLower

  if (!(hasLetter && hasDigit)) return 0
  const categories = [hasUpper, hasLower, hasDigit, hasSymbol].filter(Boolean).length
  if (categories >= 3) return 2
  return 1
})
const strengthText = computed(() => ['弱', '中', '强'][strengthLevel.value] || '')

const validatePass2 = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('请再次输入新密码'))
  } else if (value !== form.new_password) {
    callback(new Error('两次新密码不一致'))
  } else {
    callback()
  }
}

const rules = {
  old_password: [{ required: true, message: '请输入原密码', trigger: 'blur' }],
  new_password: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 8, max: 16, message: '密码长度 8-16 位', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (!/^(?=.*[a-zA-Z])(?=.*\d).+$/.test(value)) {
          callback(new Error('密码需同时包含字母和数字'))
        } else if (value === form.old_password) {
          callback(new Error('新密码不能与原密码相同'))
        } else {
          callback()
        }
      },
      trigger: 'blur',
    },
  ],
  new_password_confirm: [{ validator: validatePass2, trigger: 'blur' }],
}

async function onSubmit() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch {
    return
  }

  loading.value = true
  try {
    await authStore.changePassword({
      old_password: form.old_password,
      new_password: form.new_password,
      new_password_confirm: form.new_password_confirm,
    })

    ElMessage.success('密码修改成功')

    // 跳转到对应主页
    const role = authStore.user?.role
    if (role === 1) {
      router.push('/admin')
    } else {
      router.push('/staff')
    }
  } catch (e) {
    // 错误已在拦截器中提示
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-lg);
  position: relative;
  overflow: hidden;
}

.bg-decor {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}
.bg-blob {
  position: absolute;
  width: 400px;
  height: 400px;
  border-radius: 50%;
  background: var(--color-primary);
  filter: blur(80px);
  opacity: 0.3;
  top: -100px;
  left: 50%;
  transform: translateX(-50%);
  animation: float 12s ease-in-out infinite;
}
@keyframes float {
  0%, 100% { transform: translateX(-50%) scale(1); }
  50% { transform: translateX(-50%) translateY(-30px) scale(1.05); }
}

.auth-card {
  position: relative;
  z-index: 1;
  width: 440px;
  max-width: 100%;
  padding: var(--space-xl);
}

.card-header {
  text-align: center;
  margin-bottom: var(--space-xl);
}

.logo-mark {
  width: 64px;
  height: 64px;
  border-radius: 18px;
  background: var(--gradient-primary);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  color: #fff;
  margin-bottom: var(--space-md);
  box-shadow: var(--shadow-glow);
}

.card-header h1 {
  font-size: 26px;
  font-weight: 700;
  color: var(--color-text);
  margin-bottom: 8px;
}

.warn-tip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--color-accent);
  font-size: 13px;
  background: #fff7ed;
  padding: 6px 14px;
  border-radius: var(--radius-full);
  border: 1px solid #fed7aa;
}

.submit-btn {
  width: 100%;
  height: 46px;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 2px;
  border-radius: var(--radius-md);
}

.card-footer {
  text-align: center;
  margin-top: var(--space-md);
  font-size: 13px;
}

/* 密码要求 + 强度 */
.pwd-tips {
  margin: -8px 0 var(--space-md);
  padding: 12px 14px;
  background: #f8fafc;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
}
.pwd-rules {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  margin-bottom: 10px;
}
.pwd-rules-label {
  color: var(--color-text-muted);
}
.pwd-rule {
  color: var(--color-text-muted);
  padding: 2px 8px;
  border-radius: var(--radius-full);
  background: #f1f5f9;
  transition: all 0.25s;
}
.pwd-rule.ok {
  color: var(--color-success);
  background: rgba(46, 204, 113, 0.12);
}
.pwd-strength {
  display: flex;
  align-items: center;
  gap: 10px;
}
.strength-bars {
  display: flex;
  gap: 4px;
  flex: 1;
}
.bar {
  height: 4px;
  flex: 1;
  background: #e2e8f0;
  border-radius: 2px;
  transition: background 0.3s;
}
.bar.active {
  background: var(--color-accent);
}
.strength-bars.level-0 .bar.active { background: var(--color-danger); }
.strength-bars.level-1 .bar.active { background: var(--color-warning); }
.strength-bars.level-2 .bar.active { background: var(--color-success); }
.strength-label {
  font-size: 12px;
  color: var(--color-text-muted);
  min-width: 30px;
}
.strength-label.level-0 { color: var(--color-danger); }
.strength-label.level-1 { color: var(--color-warning); }
.strength-label.level-2 { color: var(--color-success); }

@media (max-width: 768px) {
  .auth-card {
    width: 100%;
    padding: var(--space-lg) var(--space-md);
  }
  .card-header h1 {
    font-size: 22px;
  }
  .logo-mark {
    width: 52px;
    height: 52px;
    font-size: 24px;
  }
}
</style>
