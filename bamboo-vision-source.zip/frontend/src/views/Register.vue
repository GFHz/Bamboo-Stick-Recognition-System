<template>
  <div class="auth-page">
    <div class="bg-decor">
      <div class="bg-blob bg-blob-1"></div>
      <div class="bg-blob bg-blob-2"></div>
    </div>

    <div class="auth-container glass-card fade-in">
      <div class="brand-panel">
        <div class="brand-logo">
          <div class="logo-mark">管</div>
        </div>
        <h1 class="brand-title">管理员注册</h1>
        <p class="brand-tagline">注册账号 · 管理店铺 · 数据掌控</p>
      </div>

      <div class="form-panel">
        <div class="form-header">
          <h2>创建管理员账号</h2>
          <p>注册后即可登录管理员后台</p>
        </div>

        <el-form ref="formRef" :model="form" :rules="rules" label-position="top" size="large">
          <el-form-item prop="username" label="账号">
            <el-input v-model="form.username" placeholder="3-32 位字符" :prefix-icon="User" />
          </el-form-item>

          <el-form-item prop="name" label="真实姓名">
            <el-input v-model="form.name" placeholder="请输入真实姓名" :prefix-icon="UserFilled" />
          </el-form-item>

          <el-form-item prop="password" label="密码">
            <el-input
              v-model="form.password"
              type="password"
              placeholder="8-16 位，需含字母和数字"
              :prefix-icon="Lock"
              show-password
            />
          </el-form-item>

          <el-form-item prop="password_confirm" label="确认密码">
            <el-input
              v-model="form.password_confirm"
              type="password"
              placeholder="请再次输入密码"
              :prefix-icon="Lock"
              show-password
              @keyup.enter="onRegister"
            />
          </el-form-item>

          <!-- 密码强度提示 -->
          <div class="pwd-strength" v-if="form.password">
            <div class="strength-bars" :class="`level-${strengthLevel}`">
              <span v-for="i in 3" :key="i" class="bar" :class="{ active: i <= strengthLevel }"></span>
            </div>
            <span class="strength-label" :class="`level-${strengthLevel}`">{{ strengthText }}</span>
          </div>

          <el-form-item>
            <el-button
              type="primary"
              class="submit-btn"
              :loading="loading"
              @click="onRegister"
            >
              {{ loading ? '注册中...' : '注 册' }}
            </el-button>
          </el-form-item>
        </el-form>

        <div class="form-footer">
          <span>已有账号？</span>
          <router-link to="/login">返回登录</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, UserFilled, Lock } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import { showCaptcha } from '@/utils/captcha'

const router = useRouter()
const authStore = useAuthStore()

const formRef = ref(null)
const loading = ref(false)

const form = reactive({
  username: '',
  name: '',
  password: '',
  password_confirm: '',
})

// 密码强度（三档）
// weak: 长度不符 / 纯数字 / 纯字母 → 0
// medium: 字母+数字 → 1
// strong: 3 类以上字符（大写/小写/数字/符号）→ 2
const strengthLevel = computed(() => {
  const p = form.password
  if (!p) return 0
  if (p.length < 8 || p.length > 16) return 0

  const hasUpper = /[A-Z]/.test(p)
  const hasLower = /[a-z]/.test(p)
  const hasDigit = /\d/.test(p)
  const hasSymbol = /[^A-Za-z0-9]/.test(p)

  const hasLetter = hasUpper || hasLower

  // 不满足字母+数字 → 弱
  if (!(hasLetter && hasDigit)) return 0

  // 3 类以上 → 强
  const categories = [hasUpper, hasLower, hasDigit, hasSymbol].filter(Boolean).length
  if (categories >= 3) return 2

  // 字母+数字 → 中
  return 1
})

const strengthText = computed(() => {
  return ['弱', '中', '强'][strengthLevel.value] || ''
})

const validatePass2 = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('请再次输入密码'))
  } else if (value !== form.password) {
    callback(new Error('两次密码不一致'))
  } else {
    callback()
  }
}

const rules = {
  username: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { min: 3, max: 32, message: '账号长度 3-32 位', trigger: 'blur' },
  ],
  name: [{ required: true, message: '请输入真实姓名', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 8, max: 16, message: '密码长度 8-16 位', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (!/^(?=.*[a-zA-Z])(?=.*\d).+$/.test(value)) {
          callback(new Error('密码需同时包含字母和数字'))
        } else {
          callback()
        }
      },
      trigger: 'blur',
    },
  ],
  password_confirm: [{ validator: validatePass2, trigger: 'blur' }],
}

async function onRegister() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch {
    return
  }

  // 滑块验证
  let captcha = { ticket: '', randstr: '' }
  try {
    captcha = await showCaptcha()
  } catch {
    return
  }

  loading.value = true
  try {
    await authStore.register({
      username: form.username,
      name: form.name,
      password: form.password,
      password_confirm: form.password_confirm,
      captcha_ticket: captcha.ticket,
      captcha_randstr: captcha.randstr,
    })

    ElMessage.success('注册成功，请登录')
    router.push('/login')
  } catch (e) {
    // 错误已在拦截器中提示
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-lg);
  position: relative;
  overflow: hidden;
}

.bg-decor {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}
.bg-blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
  animation: float 12s ease-in-out infinite;
}
.bg-blob-1 {
  width: 400px;
  height: 400px;
  background: var(--color-primary);
  top: -100px;
  right: -100px;
}
.bg-blob-2 {
  width: 350px;
  height: 350px;
  background: var(--color-accent);
  bottom: -100px;
  left: -50px;
  animation-delay: -4s;
}
@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(-40px, -30px) scale(1.05); }
  66% { transform: translate(30px, 40px) scale(0.95); }
}

.auth-container {
  position: relative;
  z-index: 1;
  display: flex;
  width: 900px;
  max-width: 100%;
  min-height: 600px;
  overflow: hidden;
}

.brand-panel {
  flex: 1;
  padding: var(--space-xl);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #eff6ff, #e0f2fe);
  border-right: 1px solid var(--color-border);
}

.brand-logo {
  margin-bottom: var(--space-lg);
}
.logo-mark {
  width: 80px;
  height: 80px;
  border-radius: 24px;
  background: var(--gradient-accent);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 38px;
  font-weight: 900;
  color: #fff;
  box-shadow: var(--shadow-glow);
}

.brand-title {
  font-size: 32px;
  font-weight: 800;
  color: var(--color-text);
  margin-bottom: var(--space-sm);
  letter-spacing: 2px;
}
.brand-tagline {
  color: var(--color-text-secondary);
  font-size: 14px;
  letter-spacing: 1px;
}

.form-panel {
  flex: 1;
  padding: var(--space-xl);
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-header {
  margin-bottom: var(--space-lg);
  text-align: center;
}
.form-header h2 {
  font-size: 24px;
  font-weight: 700;
  color: var(--color-text);
  margin-bottom: 6px;
}
.form-header p {
  color: var(--color-text-muted);
  font-size: 13px;
}

.pwd-strength {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: -8px 0 var(--space-md);
}
.strength-bars {
  display: flex;
  gap: 4px;
  flex: 1;
}
.bar {
  height: 4px;
  flex: 1;
  background: #e2e8f0;
  border-radius: 2px;
  transition: background 0.3s;
}
.bar.active {
  background: var(--color-accent);
}
.strength-bars.level-0 .bar.active { background: var(--color-danger); }
.strength-bars.level-1 .bar.active { background: var(--color-warning); }
.strength-bars.level-2 .bar.active { background: var(--color-success); }
.strength-label {
  font-size: 12px;
  color: var(--color-text-muted);
  min-width: 30px;
}
.strength-label.level-0 { color: var(--color-danger); }
.strength-label.level-1 { color: var(--color-warning); }
.strength-label.level-2 { color: var(--color-success); }

.submit-btn {
  width: 100%;
  height: 46px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 4px;
  border-radius: var(--radius-md);
}

.form-footer {
  margin-top: var(--space-lg);
  text-align: center;
  color: var(--color-text-muted);
  font-size: 13px;
}
.form-footer a {
  margin-left: 6px;
  font-weight: 600;
}

@media (max-width: 768px) {
  .auth-container {
    flex-direction: column;
    width: 100%;
    min-height: auto;
  }
  .brand-panel {
    padding: var(--space-lg);
    border-right: none;
    border-bottom: 1px solid var(--color-border);
  }
  .form-panel {
    padding: var(--space-lg);
  }
}
</style>
