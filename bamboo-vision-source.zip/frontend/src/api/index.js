/**
 * API 模块统一导出
 */
import auth from './auth'
import price from './price'
import order from './order'
import admin from './admin'

export { auth, price, order, admin }
