import request from '@/utils/request'

export default {
  /** 管理员注册 */
  register(data) {
    return request.post('/auth/register', data)
  },
  /** 登录 */
  login(data) {
    return request.post('/auth/login', data)
  },
  /** 获取当前用户 */
  me() {
    return request.get('/auth/me')
  },
  /** 修改密码 */
  changePassword(data) {
    return request.post('/auth/change-password', data)
  },
}
