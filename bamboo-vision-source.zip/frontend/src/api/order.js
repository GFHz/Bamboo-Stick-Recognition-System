import request from '@/utils/request'

export default {
  /** 上传图片做竹签计数 */
  count(formData) {
    return request.post('/orders/count', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 60000, // 模型推理可能较慢
    })
  },
  /** 创建订单 */
  create(data) {
    return request.post('/orders', data)
  },
  /** 我的订单 */
  mine(params) {
    return request.get('/orders/me', { params })
  },
  /** 所有订单（管理员） */
  list(params) {
    return request.get('/orders', { params })
  },
  /** 改备注 */
  updateRemark(id, remark) {
    return request.patch(`/orders/${id}/remark`, { remark })
  },
  /** 撤销订单 */
  cancel(id) {
    return request.post(`/orders/${id}/cancel`)
  },
}
