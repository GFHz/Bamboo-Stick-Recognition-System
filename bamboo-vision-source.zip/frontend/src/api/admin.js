import request from '@/utils/request'

export default {
  /** 新增员工 */
  createStaff(data) {
    return request.post('/admin/staffs', data)
  },
  /** 员工列表 */
  listStaffs(params) {
    return request.get('/admin/staffs', { params })
  },
  /** 删除员工 */
  deleteStaff(id) {
    return request.delete(`/admin/staffs/${id}`)
  },
  /** 切换员工状态（1=启用, 0=停用） */
  toggleStaffStatus(id, is_active) {
    return request.patch(`/admin/staffs/${id}/status`, { is_active })
  },
  /** 首页汇总 */
  dashboard() {
    return request.get('/admin/dashboard')
  },
  /** 按日期统计 */
  stats(params) {
    return request.get('/admin/stats', { params })
  },
  /** 导出订单 Excel */
  exportUrl(start, end) {
    // 通过 fetch 拿到 blob，避免 axios 直接处理
    return request.get('/admin/export', {
      params: { start_date: start, end_date: end },
      responseType: 'blob',
    })
  },
}
