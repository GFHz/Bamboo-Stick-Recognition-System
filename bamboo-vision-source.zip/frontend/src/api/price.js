import request from '@/utils/request'

export default {
  /** 设置单价 */
  set(data) {
    return request.post('/prices', data)
  },
  /** 价格列表 */
  list(params) {
    return request.get('/prices', { params })
  },
  /** 当前价格 */
  current() {
    return request.get('/prices/current')
  },
}
