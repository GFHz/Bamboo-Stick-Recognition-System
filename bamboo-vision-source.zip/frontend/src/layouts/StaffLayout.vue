<template>
  <div class="layout-wrapper">
    <!-- 手机端顶栏 -->
    <header class="mobile-header">
      <el-icon class="menu-btn" @click="drawerOpen = true"><Expand /></el-icon>
      <span class="mobile-title">{{ currentTitle }}</span>
    </header>

    <!-- 遮罩层 -->
    <div class="drawer-mask" v-if="drawerOpen" @click="drawerOpen = false"></div>

    <!-- 侧边栏 -->
    <aside class="sidebar glass-card" :class="{ 'drawer-open': drawerOpen }">
      <div class="logo">
        <div class="logo-icon">签</div>
        <div class="logo-text">
          <span class="logo-title">竹签计价</span>
          <span class="logo-sub">员工端</span>
        </div>
      </div>

      <nav class="nav-list">
        <router-link
          v-for="item in menu"
          :key="item.path"
          :to="item.path"
          class="nav-item"
          active-class="active"
          @click="drawerOpen = false"
        >
          <el-icon class="nav-icon"><component :is="item.icon" /></el-icon>
          <span>{{ item.label }}</span>
        </router-link>
      </nav>

      <div class="sidebar-footer">
        <div class="user-info">
          <el-avatar :size="36" class="user-avatar">
            {{ user?.name?.charAt(0) || '员' }}
          </el-avatar>
          <div class="user-meta">
            <div class="user-name">{{ user?.name || '员工' }}</div>
            <div class="user-id">{{ user?.username }}</div>
          </div>
        </div>
        <el-dropdown @command="onCommand" trigger="click">
          <el-icon class="more-icon"><MoreFilled /></el-icon>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="password">修改密码</el-dropdown-item>
              <el-dropdown-item divided command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </aside>

    <!-- 主内容区 -->
    <main class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessageBox, ElMessage } from 'element-plus'
import { Camera, List, MoreFilled, Expand } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const user = computed(() => authStore.user)

const drawerOpen = ref(false)
const menu = [
  { path: '/staff/count', label: '竹签计数', icon: Camera },
  { path: '/staff/orders', label: '我的订单', icon: List },
]
const currentTitle = computed(() => {
  const item = menu.find(m => route.path.startsWith(m.path))
  return item?.label || '竹签计价'
})

function onCommand(cmd) {
  if (cmd === 'logout') {
    ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      type: 'warning',
    })
      .then(() => {
        authStore.logout()
        ElMessage.success('已退出登录')
        router.push('/login')
      })
      .catch(() => {})
  } else if (cmd === 'password') {
    router.push('/change-password')
  }
}
</script>

<style scoped>
.layout-wrapper {
  display: flex;
  min-height: 100vh;
  padding: var(--space-lg);
  gap: var(--space-lg);
}

.sidebar {
  width: 240px;
  flex-shrink: 0;
  padding: var(--space-lg);
  display: flex;
  flex-direction: column;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: var(--space-md) var(--space-sm);
  margin-bottom: var(--space-xl);
}

.logo-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: var(--gradient-fire);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 20px;
  color: #fff;
  box-shadow: var(--shadow-glow);
}

.logo-text {
  display: flex;
  flex-direction: column;
}
.logo-title {
  font-size: 18px;
  font-weight: 700;
  color: var(--color-text);
}
.logo-sub {
  font-size: 12px;
  color: var(--color-text-muted);
  letter-spacing: 2px;
}

.nav-list {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: var(--radius-md);
  color: var(--color-text-secondary);
  transition: all 0.25s;
  cursor: pointer;
}
.nav-item:hover {
  color: var(--color-primary);
  background: #eff6ff;
}
.nav-item.active {
  background: var(--gradient-primary);
  color: #fff;
  box-shadow: var(--shadow-glow);
}
.nav-icon {
  font-size: 18px;
}

.sidebar-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-md) var(--space-sm);
  border-top: 1px solid var(--color-border);
  margin-top: var(--space-md);
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}
.user-avatar {
  background: var(--gradient-accent);
  color: #fff;
  font-weight: 700;
}
.user-meta {
  display: flex;
  flex-direction: column;
}
.user-name {
  font-size: 14px;
  color: var(--color-text);
  font-weight: 600;
}
.user-id {
  font-size: 12px;
  color: var(--color-text-muted);
}

.more-icon {
  color: var(--color-text-muted);
  cursor: pointer;
  font-size: 18px;
}

.main-content {
  flex: 1;
  overflow-x: auto;
  min-width: 0;
}

/* 手机端顶栏：PC端隐藏 */
.mobile-header {
  display: none;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s, transform 0.25s;
}
.fade-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.fade-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}

@media (max-width: 768px) {
  .layout-wrapper {
    flex-direction: column;
    padding: 0;
    gap: 0;
  }
  .mobile-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: #fff;
    border-bottom: 1px solid var(--color-border);
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .menu-btn {
    font-size: 22px;
    cursor: pointer;
    color: var(--color-text);
  }
  .mobile-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--color-text);
  }
  .drawer-mask {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.4);
    z-index: 150;
  }
  .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 260px;
    transform: translateX(-100%);
    transition: transform 0.3s ease;
    z-index: 200;
    border-radius: 0;
  }
  .sidebar.drawer-open {
    transform: translateX(0);
  }
  .main-content {
    padding: var(--space-sm);
  }
}
</style>
