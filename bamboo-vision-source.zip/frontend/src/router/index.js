import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  {
    path: '/',
    redirect: '/login',
  },
  // ============ 公共页面 ============
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { public: true, title: '登录' },
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/Register.vue'),
    meta: { public: true, title: '管理员注册' },
  },
  {
    path: '/change-password',
    name: 'ChangePassword',
    component: () => import('@/views/ChangePassword.vue'),
    meta: { title: '修改密码' },
  },

  // ============ 员工端 ============
  {
    path: '/staff',
    component: () => import('@/layouts/StaffLayout.vue'),
    meta: { requiresAuth: true, role: 'staff' },
    children: [
      { path: '', redirect: '/staff/count' },
      {
        path: 'count',
        name: 'StaffCount',
        component: () => import('@/views/staff/Count.vue'),
        meta: { title: '竹签计数' },
      },
      {
        path: 'orders',
        name: 'StaffOrders',
        component: () => import('@/views/staff/Orders.vue'),
        meta: { title: '我的订单' },
      },
    ],
  },

  // ============ 管理员端 ============
  {
    path: '/admin',
    component: () => import('@/layouts/AdminLayout.vue'),
    meta: { requiresAuth: true, role: 'admin' },
    children: [
      { path: '', redirect: '/admin/dashboard' },
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/Dashboard.vue'),
        meta: { title: '首页汇总' },
      },
      {
        path: 'stats',
        name: 'AdminStats',
        component: () => import('@/views/admin/Stats.vue'),
        meta: { title: '订单统计' },
      },
      {
        path: 'staffs',
        name: 'AdminStaffs',
        component: () => import('@/views/admin/Staffs.vue'),
        meta: { title: '员工管理' },
      },
      {
        path: 'price',
        name: 'AdminPrice',
        component: () => import('@/views/admin/Price.vue'),
        meta: { title: '价格设置' },
      },
    ],
  },

  // ============ 404 ============
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: { public: true, title: '页面不存在' },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// 全局前置守卫
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()

  // 设置标题
  if (to.meta.title) {
    document.title = `${to.meta.title} - 竹签自动计价系统`
  }

  // 公共页面直接放行
  if (to.meta.public) {
    // 已登录用户访问登录页 → 跳转对应主页
    if (to.name === 'Login' && authStore.isLoggedIn) {
      const role = authStore.user?.role
      return next(role === 1 ? '/admin' : '/staff')
    }
    return next()
  }

  // 需要登录
  if (to.meta.requiresAuth && !authStore.isLoggedIn) {
    return next('/login')
  }

  // 角色校验
  if (to.meta.role === 'admin' && !authStore.isAdmin) {
    return next('/staff')
  }
  if (to.meta.role === 'staff' && !authStore.isStaff) {
    return next('/admin')
  }

  // 首次登录强制改密
  if (
    authStore.mustChangePassword &&
    to.name !== 'ChangePassword' &&
    to.name !== 'Login'
  ) {
    return next('/change-password')
  }

  next()
})

export default router
