<template>
  <div class="number-pad">
    <button
      v-for="key in keys"
      :key="key.label"
      type="button"
      class="pad-key"
      :class="{ 'key-action': key.type !== 'digit' }"
      @click="onKey(key)"
    >
      {{ key.label }}
    </button>
  </div>
</template>

<script setup>
/**
 * 纯数字键盘组件
 * - 只允许数字按键 + 退格 + 清零
 * - 不允许输入小数点、字母、符号
 */
import { computed } from 'vue'

const props = defineProps({
  modelValue: { type: Number, default: 0 },
  max: { type: Number, default: 99999 },
  recognized: { type: Boolean, default: false },
})

const emit = defineEmits(['update:modelValue', 'manual-edit'])

const keys = [
  { label: '1', type: 'digit', value: 1 },
  { label: '2', type: 'digit', value: 2 },
  { label: '3', type: 'digit', value: 3 },
  { label: '4', type: 'digit', value: 4 },
  { label: '5', type: 'digit', value: 5 },
  { label: '6', type: 'digit', value: 6 },
  { label: '7', type: 'digit', value: 7 },
  { label: '8', type: 'digit', value: 8 },
  { label: '9', type: 'digit', value: 9 },
  { label: '清零', type: 'clear' },
  { label: '0', type: 'digit', value: 0 },
  { label: '⌫', type: 'back' },
]

function onKey(key) {
  const current = String(props.modelValue || 0)
  let next = current

  if (key.type === 'digit') {
    // 如果当前值来自机器识别且非0，首次输入替换整个值（而非追加）
    if (props.recognized && current !== '0') {
      next = String(key.value)
      emit('manual-edit')
    } else if (current === '0') {
      // 避免前导 0
      next = String(key.value)
    } else {
      next = current + String(key.value)
    }
    // 长度限制
    if (next.length > 6) return
    const n = parseInt(next, 10)
    if (n > props.max) return
    emit('update:modelValue', n)
  } else if (key.type === 'back') {
    if (current.length <= 1) {
      emit('update:modelValue', 0)
    } else {
      emit('update:modelValue', parseInt(current.slice(0, -1), 10))
    }
  } else if (key.type === 'clear') {
    emit('update:modelValue', 0)
  }
}
</script>

<style scoped>
.number-pad {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}

.pad-key {
  height: 48px;
  border: 1px solid var(--color-border);
  background: #fff;
  color: var(--color-text);
  font-size: 18px;
  font-weight: 600;
  font-family: var(--font-mono);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all 0.15s;
  user-select: none;
}
.pad-key:hover {
  background: #eff6ff;
  border-color: var(--color-primary);
  color: var(--color-primary);
  transform: translateY(-1px);
}
.pad-key:active {
  transform: translateY(1px);
  background: #dbeafe;
}
.key-action {
  font-size: 14px;
  color: var(--color-text-secondary);
  font-family: var(--font-sans);
}
.key-action:hover {
  color: var(--color-accent);
  border-color: var(--color-accent);
  background: #fff7ed;
}

/* 响应式：小屏按钮变矮 */
@media (max-width: 768px) {
  .pad-key {
    height: 42px;
    font-size: 16px;
  }
}
</style>
