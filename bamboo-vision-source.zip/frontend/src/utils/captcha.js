/**
 * 腾讯云滑块验证码封装
 * 文档：https://cloud.tencent.com/document/product/1110/36841
 *
 * 使用方式：
 *   const { ticket, randstr } = await showCaptcha()
 */
import { ElMessage } from 'element-plus'

const APP_ID = import.meta.env.VITE_CAPTCHA_APP_ID || ''
const ENABLED = (import.meta.env.VITE_CAPTCHA_ENABLED || 'false').toLowerCase() === 'true'

/** 动态加载腾讯云验证码 SDK */
function loadScript() {
  return new Promise((resolve, reject) => {
    if (window.TencentCaptcha) {
      resolve()
      return
    }
    const script = document.createElement('script')
    script.src = 'https://turing.captcha.qcloud.com/TCaptcha.js'
    script.onload = resolve
    script.onerror = () => reject(new Error('验证码 SDK 加载失败'))
    document.head.appendChild(script)
  })
}

/**
 * 弹出滑块验证
 * @returns {Promise<{ticket: string, randstr: string} | null>}
 */
export async function showCaptcha() {
  // 未启用验证码 → 直接返回空对象
  if (!ENABLED) {
    return { ticket: '', randstr: '' }
  }
  try {
    await loadScript()
  } catch (e) {
    ElMessage.error('验证码加载失败，请稍后重试')
    throw e
  }

  return new Promise((resolve, reject) => {
    // eslint-disable-next-line no-new
    new window.TencentCaptcha(APP_ID, (res) => {
      if (res.ret === 0) {
        resolve({ ticket: res.ticket, randstr: res.randstr })
      } else {
        // 用户关闭验证码
        reject(new Error('验证未通过'))
      }
    }).show()
  })
}
