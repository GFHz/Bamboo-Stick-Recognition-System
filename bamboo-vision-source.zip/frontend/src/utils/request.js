/**
 * Axios 实例封装
 * - baseURL 走 Vite 代理
 * - 请求拦截器：自动附加 JWT
 * - 响应拦截器：401 自动登出跳转
 */
import axios from 'axios'
import { ElMessage } from 'element-plus'

const request = axios.create({
  baseURL: '/api',
  timeout: 30000,
})

// 请求拦截器
request.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (err) => Promise.reject(err),
)

// 响应拦截器
request.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const { response, config } = error
    if (response) {
      // 后端返回的 detail
      const detail = response.data?.detail
      const msg = typeof detail === 'string' ? detail : (detail?.[0]?.msg || `请求失败 (${response.status})`)

      // 登录接口的 401 是账号/密码错误，不能当成 token 过期处理
      const isLoginRequest = config?.url?.includes('/auth/login')

      if (response.status === 401 && !isLoginRequest) {
        // token 过期/无效
        localStorage.removeItem('access_token')
        localStorage.removeItem('user_info')
        ElMessage.error('登录已过期，请重新登录')
        // 跳转登录页（避免在登录页死循环）
        if (!window.location.pathname.startsWith('/login')) {
          window.location.href = '/login'
        }
      } else {
        // 登录失败、或其他业务错误，显示后端返回的具体消息
        ElMessage.error(msg)
      }
    } else {
      ElMessage.error('网络异常，请稍后重试')
    }
    return Promise.reject(error)
  },
)

export default request
